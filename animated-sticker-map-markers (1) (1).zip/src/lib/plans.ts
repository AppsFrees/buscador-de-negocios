import type { BillingInterval, PlanId } from "./types";

export type PlanDef = {
  id: PlanId;
  name: string;
  tagline: string;
  monthly: number;
  yearly: number;
  markerBg: string;
  markerScale: number;
  animSpeed: string;
  maxLocations: number;
  verified: boolean;
  boosts: number;
  badge?: string;
  crown?: boolean;
  halo?: boolean;
  accent: string;
  chip: string;
  features: string[];
  limits: { label: string; value: string }[];
};

export const PLANS: Record<PlanId, PlanDef> = {
  free: {
    id: "free",
    name: "Básico",
    tagline: "Aparece en el mapa sin pagar nada",
    monthly: 0,
    yearly: 0,
    markerBg: "#e8ecf4",
    markerScale: 1,
    animSpeed: "3.4s",
    maxLocations: 1,
    verified: false,
    boosts: 0,
    accent: "#94a3b8",
    chip: "bg-slate-200 text-ink",
    features: [
      "1 marcador plateado en el mapa",
      "Ficha con foto, descripción y horario",
      "Botón “Cómo llegar” en Google Maps",
      "Estadísticas de los últimos 7 días",
    ],
    limits: [
      { label: "Marcadores", value: "1" },
      { label: "Datos de contacto", value: "Teléfono" },
      { label: "Prioridad en el mapa", value: "Baja" },
    ],
  },
  gold: {
    id: "gold",
    name: "Gold",
    tagline: "El favorito de los negocios del centro",
    monthly: 9.99,
    yearly: 95.9,
    markerBg: "#ffc93c",
    markerScale: 1.3,
    animSpeed: "1.8s",
    maxLocations: 5,
    verified: true,
    boosts: 2,
    badge: "TOP",
    accent: "#ffc93c",
    chip: "bg-gold text-ink",
    features: [
      "Hasta 5 marcadores dorados más grandes",
      "Sello “Verificado” y flotación destacada",
      "Teléfono, WhatsApp y botón de llamada",
      "Estadísticas completas de 30 días",
      "2 impulsos mensuales (30 min en portada)",
    ],
    limits: [
      { label: "Marcadores", value: "5" },
      { label: "Datos de contacto", value: "Teléfono + WhatsApp" },
      { label: "Prioridad en el mapa", value: "Alta" },
    ],
  },
  platinum: {
    id: "platinum",
    name: "Platinum",
    tagline: "Máxima visibilidad y herramientas pro",
    monthly: 19.99,
    yearly: 191.9,
    markerBg: "#a855f7",
    markerScale: 1.5,
    animSpeed: "1s",
    maxLocations: 25,
    verified: true,
    boosts: 8,
    badge: "VIP",
    crown: true,
    halo: true,
    accent: "#a855f7",
    chip: "bg-plum text-white",
    features: [
      "Hasta 25 marcadores VIP con halo animado",
      "Corona VIP y prioridad máxima de render",
      "Cupones y promociones en tu ficha",
      "Estadísticas pro + exportación de datos",
      "8 impulsos mensuales y soporte prioritario",
    ],
    limits: [
      { label: "Marcadores", value: "25" },
      { label: "Datos de contacto", value: "Ilimitados" },
      { label: "Prioridad en el mapa", value: "Máxima" },
    ],
  },
};

export const PLAN_ORDER: PlanId[] = ["free", "gold", "platinum"];

export function planPrice(plan: PlanId, interval: BillingInterval) {
  return PLANS[plan][interval];
}

/** Yearly saves 2 months (~20%). */
export function yearlySavings(plan: PlanId) {
  const full = PLANS[plan].monthly * 12;
  return Math.max(0, full - PLANS[plan].yearly);
}

export function priceLabel(plan: PlanId, interval: BillingInterval) {
  const p = planPrice(plan, interval);
  if (p === 0) return "Gratis";
  const period = interval === "monthly" ? "/mes" : "/año";
  return `$${p.toFixed(2)}${period}`;
}

export const COUPONS: Record<string, { percentOff: number; label: string }> = {
  MAPA20: { percentOff: 20, label: "20% de descuento para siempre" },
  BIENVENIDA: { percentOff: 100, label: "Primer mes gratis" },
  AYACUCHO10: { percentOff: 10, label: "10% de descuento local" },
};

export function discountFor(
  plan: PlanId,
  interval: BillingInterval,
  couponCode?: string | null
) {
  const base = planPrice(plan, interval);
  const coupon = couponCode ? COUPONS[couponCode.toUpperCase()] : undefined;
  const percent = coupon?.percentOff ?? 0;
  const discount = +((base * percent) / 100).toFixed(2);
  return {
    base,
    percent,
    discount,
    total: +(base - discount).toFixed(2),
    label: coupon?.label,
  };
}
