export type PlanId = "free" | "gold" | "platinum";

export type BillingInterval = "monthly" | "yearly";

export type SubscriptionStatus = "trialing" | "active" | "past_due" | "canceled";

export type Category =
  | "Café"
  | "Restaurante"
  | "Tienda"
  | "Postres"
  | "Servicios"
  | "Salud"
  | "Hoteles";

export type Business = {
  id: string;
  ownerId: string;
  name: string;
  category: Category;
  desc: string;
  plan: PlanId;
  lat: number;
  lng: number;
  img: string;
  phone: string;
  address: string;
  /** minutes from midnight, per weekday 0=Sunday */
  hours: { open: number; close: number; closed?: boolean }[];
  rating: number;
  ratingCount: number;
  views: number;
  routeClicks: number;
  verified: boolean;
  active: boolean;
  createdAt: number;
  series: number[];
  /** timestamp while a paid "boost" is running */
  boostedUntil?: number;
  /** platinum-only coupon shown on the business card */
  promo?: { code: string; label: string; percentOff: number };
};

export type Review = {
  id: string;
  businessId: string;
  author: string;
  rating: number;
  text: string;
  date: number;
};

export type PaymentCard = {
  id: string;
  brand: "visa" | "mastercard" | "amex" | "card";
  last4: string;
  expMonth: number;
  expYear: number;
  holder: string;
  isDefault: boolean;
};

export type Invoice = {
  id: string;
  number: string;
  date: number;
  description: string;
  amount: number;
  currency: string;
  status: "paid" | "open" | "refunded" | "failed";
  plan: PlanId | "addon";
  periodEnd?: number;
};

export type Subscription = {
  plan: PlanId;
  interval: BillingInterval;
  status: SubscriptionStatus;
  startedAt: number;
  currentPeriodStart: number;
  currentPeriodEnd: number;
  cancelAtPeriodEnd: boolean;
  coupon: { code: string; percentOff: number; label: string } | null;
  cardId: string | null;
  addonBoosts: number;
};

export type User = {
  id: string;
  name: string;
  email: string;
  businessName: string;
  avatarHue: number;
  createdAt: number;
};

export type Toast = {
  id: string;
  title: string;
  message?: string;
  variant: "success" | "error" | "info" | "warning";
};
