import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { COUPONS, PLANS, discountFor, planPrice } from "./plans";
import {
  buildDemoInvoices,
  buildDemoReviews,
  buildDemoUser,
  buildSeedBusinesses,
} from "./seed";
import type {
  BillingInterval,
  Business,
  Invoice,
  PaymentCard,
  PlanId,
  Review,
  Subscription,
  Toast,
  User,
} from "./types";
import { DAY, luhnValid, cardBrand, seededSeries, uid } from "./utils";

const KEY = "stickermap.state.v3";

type Persisted = {
  user: User | null;
  businesses: Business[];
  reviews: Review[];
  subscription: Subscription | null;
  cards: PaymentCard[];
  invoices: Invoice[];
  favorites: string[];
  onboarded: boolean;
};

function freshSubscription(plan: PlanId = "gold", interval: BillingInterval = "monthly"): Subscription {
  const now = Date.now();
  return {
    plan,
    interval,
    status: plan === "free" ? "active" : "trialing",
    startedAt: now,
    currentPeriodStart: now,
    currentPeriodEnd: now + (plan === "free" ? 365 * DAY : 7 * DAY),
    cancelAtPeriodEnd: false,
    coupon: null,
    cardId: null,
    addonBoosts: PLANS[plan].boosts,
  };
}

function initial(): Persisted {
  const user = buildDemoUser();
  return {
    user,
    businesses: buildSeedBusinesses(user.id),
    reviews: buildDemoReviews(),
    subscription: freshSubscription("gold"),
    cards: [],
    invoices: buildDemoInvoices(),
    favorites: [],
    onboarded: false,
  };
}

function load(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return initial();
    const parsed = JSON.parse(raw) as Partial<Persisted>;
    const base = initial();
    return { ...base, ...parsed };
  } catch {
    return initial();
  }
}

type Store = Persisted & {
  toasts: Toast[];
  toast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: string) => void;
  signIn: (name: string, email: string, businessName: string) => void;
  finishOnboarding: () => void;
  signOut: () => void;
  updateProfile: (patch: Partial<User>) => void;
  addBusiness: (b: Omit<Business, "id" | "ownerId" | "createdAt" | "series" | "views" | "routeClicks" | "rating" | "ratingCount">) => Business | null;
  updateBusiness: (id: string, patch: Partial<Business>) => void;
  deleteBusiness: (id: string) => void;
  toggleFavorite: (id: string) => void;
  addReview: (businessId: string, rating: number, text: string) => void;
  track: (id: string, field: "views" | "routeClicks") => void;
  boost: (id: string) => void;
  addCard: (c: { number: string; holder: string; exp: string; cvc: string }) => PaymentCard | null;
  removeCard: (id: string) => void;
  makeDefaultCard: (id: string) => void;
  subscribe: (args: {
    plan: PlanId;
    interval: BillingInterval;
    coupon?: string | null;
    cardId?: string | null;
    card?: { number: string; holder: string; exp: string; cvc: string };
  }) => { ok: boolean; error?: string };
  changePlan: (plan: PlanId, interval?: BillingInterval) => { ok: boolean; error?: string };
  cancelSubscription: () => void;
  resumeSubscription: () => void;
  reactivateSubscription: () => void;
  payInvoice: (id: string) => void;
  resetDemo: () => void;
};

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Persisted>(() => load());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef<number[]>([]);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage full or unavailable — app keeps working in memory */
    }
  }, [state]);

  useEffect(() => () => timers.current.forEach((t) => clearTimeout(t)), []);

  /* simulate a dunning event: the period lapsed while the app was closed */
  useEffect(() => {
    const sub = state.subscription;
    if (!sub || sub.plan === "free") return;
    if (sub.currentPeriodEnd > Date.now()) return;
    if (sub.status !== "trialing" && sub.status !== "active") return;
    setState((s) =>
      s.subscription
        ? { ...s, subscription: { ...s.subscription, status: "past_due" } }
        : s
    );
    toast({
      title: "Pago pendiente",
      message: "No pudimos cobrar tu suscripción. Actualiza tu tarjeta para no perder visibilidad.",
      variant: "error",
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
  }, []);

  const toast = useCallback(
    (t: Omit<Toast, "id">) => {
      const id = uid("toast");
      setToasts((prev) => [...prev.slice(-2), { ...t, id }]);
      const timer = window.setTimeout(() => dismissToast(id), 4200);
      timers.current.push(timer);
    },
    [dismissToast]
  );

  const value = useMemo<Store>(() => {
    const patch = (fn: (s: Persisted) => Persisted) => setState((s) => fn(s));

    const pushInvoice = (inv: Omit<Invoice, "id" | "number">): Invoice => {
      const invoice: Invoice = {
        ...inv,
        id: uid("inv"),
        number: `SM-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9000) + 1000)}`,
      };
      patch((s) => ({ ...s, invoices: [invoice, ...s.invoices] }));
      return invoice;
    };

    return {
      ...state,
      toasts,
      toast,
      dismissToast,

      signIn: (name, email, businessName) =>
        patch((s) => ({
          ...s,
          user: {
            id: s.user?.id ?? uid("user"),
            name,
            email,
            businessName,
            avatarHue: Math.floor(Math.random() * 360),
            createdAt: Date.now(),
          },
          onboarded: true,
        })),

      finishOnboarding: () => patch((s) => ({ ...s, onboarded: true })),

      signOut: () => patch((s) => ({ ...s, user: null, onboarded: false })),

      updateProfile: (p) => patch((s) => (s.user ? { ...s, user: { ...s.user, ...p } } : s)),

      addBusiness: (b) => {
        let created: Business | null = null;
        setState((s) => {
          const plan = s.subscription?.plan ?? "free";
          const owned = s.businesses.filter((x) => x.ownerId === s.user?.id);
          if (owned.length >= PLANS[plan].maxLocations) return s;
          const newId = uid("biz");
          created = {
            ...b,
            id: newId,
            ownerId: s.user?.id ?? "anon",
            createdAt: Date.now(),
            rating: 0,
            ratingCount: 0,
            views: 0,
            routeClicks: 0,
            boostedUntil: undefined,
            series: seededSeries(newId, 30, 22, 26),
          };
          return { ...s, businesses: [...s.businesses, created] };
        });
        return created;
      },

      updateBusiness: (id, p) =>
        patch((s) => ({
          ...s,
          businesses: s.businesses.map((b) => (b.id === id ? { ...b, ...p } : b)),
        })),

      deleteBusiness: (id) =>
        patch((s) => ({
          ...s,
          businesses: s.businesses.filter((b) => b.id !== id),
          favorites: s.favorites.filter((f) => f !== id),
        })),

      toggleFavorite: (id) =>
        patch((s) => ({
          ...s,
          favorites: s.favorites.includes(id)
            ? s.favorites.filter((f) => f !== id)
            : [...s.favorites, id],
        })),

      addReview: (businessId, rating, text) =>
        patch((s) => {
          const review: Review = {
            id: uid("rev"),
            businessId,
            author: s.user?.name ?? "Visitante",
            rating,
            text,
            date: Date.now(),
          };
          return {
            ...s,
            reviews: [review, ...s.reviews],
            businesses: s.businesses.map((b) =>
              b.id === businessId
                ? {
                    ...b,
                    ratingCount: b.ratingCount + 1,
                    rating:
                      Math.round(
                        ((b.rating * b.ratingCount + rating) / (b.ratingCount + 1)) * 10
                      ) / 10,
                  }
                : b
            ),
          };
        }),

      track: (id, field) =>
        patch((s) => ({
          ...s,
          businesses: s.businesses.map((b) =>
            b.id === id ? { ...b, [field]: b[field] + 1 } : b
          ),
        })),

      boost: (id) => {
        const sub = state.subscription;
        if (!sub || (sub.addonBoosts ?? 0) <= 0) return;
        patch((s) => ({
          ...s,
          subscription:
            s.subscription === null
              ? null
              : { ...s.subscription, addonBoosts: Math.max(0, s.subscription.addonBoosts - 1) },
          businesses: s.businesses.map((b) =>
            b.id === id ? { ...b, boostedUntil: Date.now() + 30 * 60 * 1000 } : b
          ),
        }));
      },

      addCard: ({ number, holder, exp, cvc }) => {
        const digits = number.replace(/\D/g, "");
        if (!luhnValid(digits) || digits.length < 13) return null;
        const m = exp.match(/^(\d{2})\/(\d{2})$/);
        if (!m || cvc.replace(/\D/g, "").length < 3) return null;
        const card: PaymentCard = {
          id: uid("card"),
          brand: cardBrand(digits),
          last4: digits.slice(-4),
          expMonth: Number(m[1]),
          expYear: 2000 + Number(m[2]),
          holder: holder.trim() || "Titular",
          isDefault: state.cards.length === 0,
        };
        patch((s) => ({
          ...s,
          cards: s.cards.length === 0 ? [card] : [...s.cards, card],
        }));
        return card;
      },

      removeCard: (id) =>
        patch((s) => ({
          ...s,
          cards: s.cards.filter((c) => c.id !== id).map((c, i, arr) => ({
            ...c,
            isDefault: arr.length ? i === 0 : false,
          })),
          subscription:
            s.subscription?.cardId === id ? { ...s.subscription, cardId: null } : s.subscription,
        })),

      makeDefaultCard: (id) =>
        patch((s) => ({
          ...s,
          cards: s.cards.map((c) => ({ ...c, isDefault: c.id === id })),
          subscription: s.subscription ? { ...s.subscription, cardId: id } : s.subscription,
        })),

      subscribe: ({ plan, interval, coupon, cardId, card }) => {
        const d = discountFor(plan, interval, coupon);
        if (d.total > 0) {
          let cid = cardId ?? state.cards.find((c) => c.isDefault)?.id ?? null;
          if (!cid && card) {
            const created = value.addCard(card);
            if (!created) return { ok: false, error: "Tarjeta inválida. Revisa los datos." };
            cid = created.id;
          }
          if (!cid) return { ok: false, error: "Necesitas una tarjeta para activar el plan." };
          patch((s) => {
            const end =
              Date.now() + (interval === "monthly" ? 30 * DAY : 365 * DAY) -
              (coupon?.toUpperCase() === "BIENVENIDA" ? 30 * DAY : 0);
            return {
              ...s,
              subscription: {
                plan,
                interval,
                status: "active",
                startedAt: Date.now(),
                currentPeriodStart: Date.now(),
                currentPeriodEnd: end,
                cancelAtPeriodEnd: false,
                coupon: d.percent > 0
                  ? {
                      code: coupon!.toUpperCase(),
                      percentOff: d.percent,
                      label: COUPONS[coupon!.toUpperCase()].label,
                    }
                  : null,
                cardId: cid,
                addonBoosts: PLANS[plan].boosts,
              },
              businesses: s.businesses.map((b) =>
                b.ownerId === s.user?.id ? { ...b, plan, verified: PLANS[plan].verified } : b
              ),
            };
          });
          pushInvoice({
            date: Date.now(),
            description: `Plan ${PLANS[plan].name} · ${interval === "monthly" ? "mensual" : "anual"}`,
            amount: d.total,
            currency: "USD",
            status: "paid",
            plan,
          });
        } else {
          patch((s) => ({
            ...s,
            subscription: {
              ...freshSubscription(plan, interval),
              status: "active",
              currentPeriodEnd: Date.now() + (plan === "free" ? 3650 * DAY : 30 * DAY),
              coupon: null,
            },
            businesses: s.businesses.map((b) =>
              b.ownerId === s.user?.id ? { ...b, plan, verified: PLANS[plan].verified } : b
            ),
          }));
        }
        return { ok: true };
      },

      changePlan: (plan, interval) => {
        const sub = state.subscription;
        if (!sub) return { ok: false, error: "Sin suscripción activa." };
        const nextInterval = interval ?? sub.interval;
        const currentTotal = discountFor(sub.plan, sub.interval, sub.coupon?.code).total;
        const nextTotal = discountFor(plan, nextInterval, sub.coupon?.code).total;
        const periodDays = sub.interval === "monthly" ? 30 : 365;
        const remaining = Math.max(
          0,
          (sub.currentPeriodEnd - Date.now()) / (periodDays * DAY)
        );
        const credit = +(currentTotal * remaining).toFixed(2);
        const due = Math.max(0, +(nextTotal - credit).toFixed(2));

        patch((s) => ({
          ...s,
          subscription: {
            ...sub,
            plan,
            interval: nextInterval,
            status: "active",
            cancelAtPeriodEnd: false,
            currentPeriodStart: Date.now(),
            currentPeriodEnd:
              Date.now() + (nextInterval === "monthly" ? 30 * DAY : 365 * DAY),
            addonBoosts: PLANS[plan].boosts,
          },
          businesses: s.businesses.map((b) =>
            b.ownerId === s.user?.id
              ? { ...b, plan, verified: PLANS[plan].verified }
              : b
          ),
        }));

        if (due > 0) {
          pushInvoice({
            date: Date.now(),
            description: `Cambio a Plan ${PLANS[plan].name} (ajuste prorrateado)`,
            amount: due,
            currency: "USD",
            status: "paid",
            plan,
          });
        }
        return { ok: true };
      },

      cancelSubscription: () =>
        patch((s) =>
          s.subscription
            ? { ...s, subscription: { ...s.subscription, cancelAtPeriodEnd: true } }
            : s
        ),

      resumeSubscription: () =>
        patch((s) =>
          s.subscription
            ? { ...s, subscription: { ...s.subscription, cancelAtPeriodEnd: false } }
            : s
        ),

      reactivateSubscription: () =>
        patch((s) => ({
          ...s,
          subscription: {
            ...(s.subscription ?? freshSubscription()),
            status: "active",
            cancelAtPeriodEnd: false,
            currentPeriodEnd: Date.now() + 30 * DAY,
          },
        })),

      payInvoice: (id) =>
        patch((s) => ({
          ...s,
          invoices: s.invoices.map((i) => (i.id === id ? { ...i, status: "paid" } : i)),
        })),

      resetDemo: () => {
        localStorage.removeItem(KEY);
        setState(initial());
      },
    };
  }, [state, toasts, toast, dismissToast]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}

/* --------------------------------------------------------------- helpers */
export function useMyBusinesses() {
  const { businesses, user } = useStore();
  return useMemo(
    () => businesses.filter((b) => b.ownerId === (user?.id ?? "__none")),
    [businesses, user]
  );
}

export function usePlanLimit() {
  const { subscription } = useStore();
  const plan = subscription?.plan ?? "free";
  return { plan, ...PLANS[plan], used: 0, price: planPrice(plan, subscription?.interval ?? "monthly") };
}
