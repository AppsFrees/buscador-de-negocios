/* ------------------------------------------------------------------ ids */
let seq = 0;
export const uid = (prefix = "id") =>
  `${prefix}_${Date.now().toString(36)}_${(seq++).toString(36)}${Math.random()
    .toString(36)
    .slice(2, 6)}`;

/* -------------------------------------------------------------- money */
export const money = (n: number, currency = "USD") =>
  new Intl.NumberFormat("es-PE", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(n);

export const moneyShort = (n: number) =>
  n >= 1000 ? `${(n / 1000).toFixed(1)}k` : `${Math.round(n)}`;

/* -------------------------------------------------------------- dates */
export const DAY = 86_400_000;

export const fmtDate = (ts: number) =>
  new Date(ts).toLocaleDateString("es-PE", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

export const fmtDateShort = (ts: number) =>
  new Date(ts).toLocaleDateString("es-PE", { day: "2-digit", month: "short" });

export const daysLeft = (ts: number) => Math.max(0, Math.ceil((ts - Date.now()) / DAY));

export const relative = (ts: number) => {
  const diff = Date.now() - ts;
  if (diff < 60_000) return "hace instantes";
  if (diff < 3_600_000) return `hace ${Math.floor(diff / 60_000)} min`;
  if (diff < DAY) return `hace ${Math.floor(diff / 3_600_000)} h`;
  if (diff < 30 * DAY) return `hace ${Math.floor(diff / DAY)} días`;
  return fmtDate(ts);
};

/* ------------------------------------------------------------- geo */
export const distanceM = (
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
) => {
  const R = 6371000;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};

export const distanceLabel = (m: number) =>
  m < 950 ? `${Math.round(m)} m` : `${(m / 1000).toFixed(1)} km`;

/* ------------------------------------------------------------- hours */
export const WEEKDAYS = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];

const hhmm = (mins: number) => {
  const m = ((mins % 1440) + 1440) % 1440;
  return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
};

export const minutesNow = () => {
  const d = new Date();
  return d.getHours() * 60 + d.getMinutes();
};

export const todayIndex = () => new Date().getDay();

export const hoursLabel = (h: { open: number; close: number; closed?: boolean }) =>
  h.closed ? "Cerrado" : `${hhmm(h.open)} – ${hhmm(h.close)}`;

export function isOpenNow(hours: { open: number; close: number; closed?: boolean }[]) {
  const today = hours[todayIndex()] ?? hours[1];
  if (!today || today.closed) return false;
  const now = minutesNow();
  return now >= today.open && now < today.close;
}

export function nextChangeLabel(hours: { open: number; close: number; closed?: boolean }[]) {
  const today = hours[todayIndex()] ?? hours[1];
  if (!today || today.closed) return "Abre mañana";
  const now = minutesNow();
  if (now < today.open) return `Abre a las ${hhmm(today.open)}`;
  if (now < today.close) return `Cierra a las ${hhmm(today.close)}`;
  return "Abre mañana";
}

export const defaultHours = () =>
  Array.from({ length: 7 }, (_, i) =>
    i === 0 ? { open: 540, close: 900, closed: true } : { open: 8 * 60, close: 21 * 60 }
  );

/* ------------------------------------------------------------ payments */
export function luhnValid(raw: string) {
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 13) return false;
  let sum = 0;
  let alt = false;
  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (alt) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    alt = !alt;
  }
  return sum % 10 === 0;
}

export function cardBrand(raw: string): "visa" | "mastercard" | "amex" | "card" {
  const d = raw.replace(/\D/g, "");
  if (/^4/.test(d)) return "visa";
  if (/^(5[1-5]|2[2-7])/.test(d)) return "mastercard";
  if (/^3[47]/.test(d)) return "amex";
  return "card";
}

export function formatCardNumber(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 16);
  return digits.replace(/(.{4})/g, "$1 ").trim();
}

export function formatExpiry(value: string) {
  const digits = value.replace(/\D/g, "").slice(0, 4);
  if (digits.length <= 2) return digits;
  return `${digits.slice(0, 2)}/${digits.slice(2)}`;
}

export function expiryValid(value: string) {
  const m = value.match(/^(\d{2})\/(\d{2})$/);
  if (!m) return false;
  const month = Number(m[1]);
  const year = 2000 + Number(m[2]);
  if (month < 1 || month > 12) return false;
  const end = new Date(year, month, 1).getTime();
  return end > Date.now();
}

/** Deterministic pseudo-random generator so charts stay stable per business. */
export function seededSeries(seed: string, days = 14, base = 90, spread = 70) {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) % 100000;
  const out: number[] = [];
  for (let i = 0; i < days; i++) {
    h = (h * 1103515245 + 12345) % 2147483648;
    const r = (h / 2147483648) * spread;
    const trend = Math.sin((i / days) * Math.PI * 1.4) * (base * 0.45);
    out.push(Math.max(4, Math.round(base + trend + r - spread / 2)));
  }
  return out;
}

export const initials = (name: string) =>
  name
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase())
    .join("") || "??";
