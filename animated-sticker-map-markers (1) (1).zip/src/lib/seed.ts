import type { Business, Invoice, Review, User } from "./types";
import { DAY, seededSeries, uid } from "./utils";

export const AYACUCHO = { lat: -13.161, lng: -74.2236 };

export const FALLBACK_IMG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd166"/><stop offset="1" stop-color="#8b5cf6"/></linearGradient></defs><rect width="120" height="120" fill="url(#g)"/><text x="60" y="76" font-size="54" text-anchor="middle" fill="#14141b" font-family="sans-serif">📍</text></svg>`
  );

const IMG = (id: string) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=480&q=70`;

const H = (open: number, close: number, closed = false) => ({ open, close, closed });
const std = () => [H(540, 840, true), H(480, 1260), H(480, 1260), H(480, 1260), H(480, 1290), H(480, 1290), H(600, 1080)];

type Seed = Omit<Business, "id" | "ownerId" | "createdAt" | "series" | "views" | "routeClicks"> & {
  views: number;
  routeClicks: number;
};

const seeds: Seed[] = [
  {
    name: "Café Wari",
    category: "Café",
    desc: "Café tostado en altura con granos de Quinua y La Mar. Baristas campeones, repostería recién horneada y un patio interior perfecto para trabajar con wifi de 200 Mb.",
    plan: "gold",
    lat: -13.1622,
    lng: -74.2241,
    img: IMG("photo-1497935586351-b67a49e012bf"),
    phone: "+51 966 412 208",
    address: "Jr. 28 de Julio 215, Ayacucho",
    hours: std(),
    rating: 4.8,
    ratingCount: 214,
    views: 4128,
    routeClicks: 386,
    verified: true,
    active: true,
  },
  {
    name: "Pizzería Plaza",
    category: "Restaurante",
    desc: "Pizza a la leña con masa madre de 48 h. La especialidad es la Ayacuchana: chorizo de la zona, choclo y ají panca. Terraza con vista a la Plaza Mayor.",
    plan: "platinum",
    lat: -13.1646,
    lng: -74.2213,
    img: IMG("photo-1513104890138-7c749659a591"),
    phone: "+51 966 730 115",
    address: "Portal Constitución 12, Plaza Mayor",
    hours: std(),
    rating: 4.9,
    ratingCount: 511,
    views: 9873,
    routeClicks: 1204,
    verified: true,
    active: true,
  },
  {
    name: "Sushi Kanto",
    category: "Restaurante",
    desc: "Fusión nikkei: rollos calientes, nigiri de trucha ahumada y barra de chilcanos. Reservas online y menú ejecutivo de lunes a jueves.",
    plan: "gold",
    lat: -13.1604,
    lng: -74.2221,
    img: IMG("photo-1579871494447-9811cf80d66c"),
    phone: "+51 966 118 447",
    address: "Av. Independencia 340",
    hours: std(),
    rating: 4.6,
    ratingCount: 178,
    views: 3211,
    routeClicks: 289,
    verified: true,
    active: true,
  },
  {
    name: "Alpaca Store",
    category: "Tienda",
    desc: "Boutique de textiles de alpaca tejidos a mano por artesanos de Quinua. Chalinas, ponchos y juguetes. Envíos a todo el país y facturación electrónica.",
    plan: "free",
    lat: -13.1661,
    lng: -74.2255,
    img: IMG("photo-1604719312566-8912e9227c6a"),
    phone: "+51 966 220 891",
    address: "Jr. Cusco 88",
    hours: std(),
    rating: 4.4,
    ratingCount: 96,
    views: 1502,
    routeClicks: 121,
    verified: false,
    active: true,
  },
  {
    name: "Heladería Lúcuma",
    category: "Postres",
    desc: "Helados artesanales de leche fresca con lúcuma, granadilla y chocolate 70%. Opciones veganas de agua de fruta. Conos caseros cada mañana.",
    plan: "free",
    lat: -13.1631,
    lng: -74.2186,
    img: IMG("photo-1557142046-c704a3adf364"),
    phone: "+51 966 552 010",
    address: "Jr. San Pedro 45",
    hours: std(),
    rating: 4.7,
    ratingCount: 143,
    views: 2088,
    routeClicks: 187,
    verified: false,
    active: true,
  },
  {
    name: "Panadería Chamizo",
    category: "Postres",
    desc: "Pan de maíz, champús y pan chuta horneados en horno de barro desde 1978. Desayunos con café pasado y mantequilla de la casa.",
    plan: "gold",
    lat: -13.1589,
    lng: -74.2252,
    img: IMG("photo-1509440159596-0249088772ff"),
    phone: "+51 966 640 771",
    address: "Av. Perú 1201",
    hours: std(),
    rating: 4.5,
    ratingCount: 132,
    views: 1894,
    routeClicks: 152,
    verified: true,
    active: true,
  },
  {
    name: "Farmacia Central",
    category: "Salud",
    desc: "Farmacia y botica con delivery en 20 minutos dentro del cercado. Consulta de medicamentos por WhatsApp y descuentos por membrecía.",
    plan: "platinum",
    lat: -13.1598,
    lng: -74.2197,
    img: IMG("photo-1587854692152-cbe660dbde88"),
    phone: "+51 966 901 335",
    address: "Jr. 2 de Mayo 505",
    hours: std(),
    rating: 4.3,
    ratingCount: 88,
    views: 2740,
    routeClicks: 402,
    verified: true,
    active: true,
  },
  {
    name: "Hostal María Parado",
    category: "Hoteles",
    desc: "Habitaciones luminosas con vista a los cerros, desayuno andino incluido y garaje privado. A 3 cuadras de la Plaza Mayor.",
    plan: "gold",
    lat: -13.1675,
    lng: -74.2178,
    img: IMG("photo-1596040033229-a9821ebd058d"),
    phone: "+51 966 377 460",
    address: "Jr. María Parado 210",
    hours: std(),
    rating: 4.6,
    ratingCount: 205,
    views: 3560,
    routeClicks: 298,
    verified: true,
    active: true,
  },
  {
    name: "Barbería 9 de Diciembre",
    category: "Servicios",
    desc: "Cortes clásicos y afeitado a navaja con toalla caliente. Reserva por hora, sin esperas. Cerveza artesanal de cortesía.",
    plan: "free",
    lat: -13.1571,
    lng: -74.2228,
    img: IMG("photo-1503951914875-452162b0f3f1"),
    phone: "+51 966 808 231",
    address: "Jr. 9 de Diciembre 77",
    hours: std(),
    rating: 4.8,
    ratingCount: 121,
    views: 1620,
    routeClicks: 141,
    verified: false,
    active: true,
  },
  {
    name: "Taller Bike Ayacucho",
    category: "Servicios",
    desc: "Mantenimiento de bicicletas y e-bikes, alquiler por horas y tours guiados a los cerros. Kit de reparación incluido en cada servicio.",
    plan: "free",
    lat: -13.1549,
    lng: -74.2266,
    img: IMG("photo-1485965120184-e220f721d03e"),
    phone: "+51 966 455 902",
    address: "Av. Jesús 1450",
    hours: std(),
    rating: 4.2,
    ratingCount: 41,
    views: 812,
    routeClicks: 66,
    verified: false,
    active: true,
  },
];

export function buildSeedBusinesses(ownerId: string): Business[] {
  return seeds.map((s, i) => ({
    ...s,
    id: `biz_seed_${i + 1}`,
    ownerId: i === 0 ? ownerId : "other_merchants",
    createdAt: Date.now() - (i + 3) * 9 * DAY,
    series: seededSeries(`biz_seed_${i + 1}`, 30, 40 + i * 11, 60),
  }));
}

export function buildDemoUser(): User {
  const id = "user_demo";
  return {
    id,
    name: "Ana Quispe",
    email: "ana@cafewari.pe",
    businessName: "Café Wari",
    avatarHue: 268,
    createdAt: Date.now() - 26 * DAY,
  };
}

export function buildDemoInvoices(): Invoice[] {
  const now = Date.now();
  return [
    {
      id: uid("inv"),
      number: "SM-2026-00871",
      date: now - 32 * DAY,
      description: "Plan Gold · mensual",
      amount: 9.99,
      currency: "USD",
      status: "paid",
      plan: "gold",
      periodEnd: now - 2 * DAY,
    },
    {
      id: uid("inv"),
      number: "SM-2026-00402",
      date: now - 64 * DAY,
      description: "Plan Gold · mensual",
      amount: 9.99,
      currency: "USD",
      status: "refunded",
      plan: "gold",
      periodEnd: now - 34 * DAY,
    },
  ];
}

export function buildDemoReviews(): Review[] {
  const now = Date.now();
  return [
    {
      id: uid("rev"),
      businessId: "biz_seed_1",
      author: "Luis M.",
      rating: 5,
      text: "El mejor capuchino del cercado y la atención es impecable. Volví tres veces en mi viaje.",
      date: now - 3 * DAY,
    },
    {
      id: uid("rev"),
      businessId: "biz_seed_1",
      author: "Rosa H.",
      rating: 4,
      text: "Muy acogedor, aunque se llena a las 8 am. El pan de maíz es increible.",
      date: now - 11 * DAY,
    },
    {
      id: uid("rev"),
      businessId: "biz_seed_2",
      author: "Diego P.",
      rating: 5,
      text: "La Pizza Ayacuchana es una locura. Terraza con vista a la plaza, 10/10.",
      date: now - 5 * DAY,
    },
    {
      id: uid("rev"),
      businessId: "biz_seed_7",
      author: "Karla V.",
      rating: 4,
      text: "Delivery súper rápido y me hicieron la consulta por WhatsApp al instante.",
      date: now - 8 * DAY,
    },
  ];
}
