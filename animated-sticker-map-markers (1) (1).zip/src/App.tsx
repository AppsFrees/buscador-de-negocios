import { useEffect, useMemo, useRef, useState } from "react";
import BillingModal from "@/components/BillingModal";
import BusinessEditor from "@/components/BusinessEditor";
import CheckoutModal from "@/components/CheckoutModal";
import DetailSheet from "@/components/DetailSheet";
import MerchantPanel from "@/components/MerchantPanel";
import MapCanvas, { MAP_STYLES, type MapHandle, type MapStyleId } from "@/components/MapCanvas";
import SearchBar, { CAT_ICONS, type SortKey } from "@/components/SearchBar";
import Toasts from "@/components/Toasts";
import Welcome from "@/components/Welcome";
import { PlanChip, Stars } from "@/components/ui";
import { PLANS } from "@/lib/plans";
import { AYACUCHO, FALLBACK_IMG } from "@/lib/seed";
import { StoreProvider, useMyBusinesses, useStore } from "@/lib/store";
import type { Business, Category, PlanId } from "@/lib/types";
import { daysLeft, distanceLabel, distanceM, isOpenNow, moneyShort } from "@/lib/utils";
import { cn } from "@/utils/cn";

export default function App() {
  return (
    <StoreProvider>
      <MapApp />
    </StoreProvider>
  );
}

function MapApp() {
  const { businesses, subscription, user, onboarded, finishOnboarding, favorites, toast } =
    useStore();
  const mine = useMyBusinesses();

  const mapRef = useRef<MapHandle | null>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Category | "Todos">("Todos");
  const [sort, setSort] = useState<SortKey>("relevancia");
  const [openOnly, setOpenOnly] = useState(false);
  const [favOnly, setFavOnly] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [userPos, setUserPos] = useState<{ lat: number; lng: number; accuracy: number } | null>(
    null
  );
  const [locating, setLocating] = useState(false);
  const [mapStyle, setMapStyle] = useState<MapStyleId>("voyager");
  const [showList, setShowList] = useState(false);

  const [pickMode, setPickMode] = useState(false);
  const [preview, setPreview] = useState<{ lat: number; lng: number; plan: PlanId } | null>(null);
  const [picked, setPicked] = useState<{ lat: number; lng: number; key: number } | null>(null);

  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<Business | null>(null);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [checkoutPlan, setCheckoutPlan] = useState<PlanId>("gold");
  const [billingOpen, setBillingOpen] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);

  const plan = PLANS[subscription?.plan ?? "free"];
  const selected = businesses.find((b) => b.id === selectedId) ?? null;

  /* ------------------------------------------------------------ filtering */
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = businesses.filter((b) => {
      if (!b.active) return false;
      if (category !== "Todos" && b.category !== category) return false;
      if (openOnly && !isOpenNow(b.hours)) return false;
      if (favOnly && !favorites.includes(b.id)) return false;
      if (!q) return true;
      return (
        b.name.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q) ||
        b.desc.toLowerCase().includes(q) ||
        b.address.toLowerCase().includes(q)
      );
    });

    const rank: Record<PlanId, number> = { platinum: 3, gold: 2, free: 1 };
    return [...list].sort((a, b) => {
      if (sort === "rating") return b.rating - a.rating;
      if (sort === "populares") return b.views - a.views;
      if (sort === "cercania") {
        if (!userPos) return rank[b.plan] - rank[a.plan];
        return distanceM(userPos, a) - distanceM(userPos, b);
      }
      const boosted =
        Number((b.boostedUntil ?? 0) > Date.now()) - Number((a.boostedUntil ?? 0) > Date.now());
      return boosted !== 0 ? -boosted : rank[b.plan] - rank[a.plan] || b.views - a.views;
    });
  }, [businesses, category, openOnly, favOnly, favorites, query, sort, userPos]);

  useEffect(() => {
    if (selectedId && !results.some((b) => b.id === selectedId)) setSelectedId(null);
  }, [results, selectedId]);

  const select = (b: Business, fly = true) => {
    setSelectedId(b.id);
    if (fly) mapRef.current?.flyTo(b.lat, b.lng, 17);
  };

  const locate = () => {
    setLocating(true);
    toast({ title: "Buscando tu ubicación…", variant: "info" });
    const fallback = () => {
      setUserPos({ lat: AYACUCHO.lat + 0.0006, lng: AYACUCHO.lng - 0.0004, accuracy: 45 });
      setLocating(false);
      toast({
        title: "GPS no disponible",
        message: "Mostramos una ubicación de demostración en el centro.",
        variant: "warning",
      });
    };
    if (!("geolocation" in navigator)) return fallback();
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const next = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };
        setUserPos(next);
        setLocating(false);
        mapRef.current?.flyTo(next.lat, next.lng, 17);
        toast({
          title: "Ubicación encontrada",
          message: `Precisión ±${Math.round(pos.coords.accuracy)} m`,
          variant: "success",
        });
      },
      fallback,
      { enableHighAccuracy: true, timeout: 6000, maximumAge: 0 }
    );
  };

  const openEditor = (b: Business | null) => {
    setEditing(b);
    setEditorOpen(true);
    if (b) mapRef.current?.flyTo(b.lat, b.lng, 16);
  };

  const openCheckout = (p: PlanId = "gold") => {
    setCheckoutPlan(p);
    setBillingOpen(false);
    setPanelOpen(false);
    setCheckoutOpen(true);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-ink">
      <MapCanvas
        ref={mapRef}
        businesses={results}
        selectedId={selectedId}
        onSelect={(b) => select(b)}
        userPos={userPos}
        mapStyle={mapStyle}
        pickMode={pickMode}
        preview={preview}
        onPick={(lat, lng) => {
          if (!pickMode) return;
          setPicked({ lat, lng, key: Date.now() });
          setPreview({ lat, lng, plan: subscription?.plan ?? "free" });
        }}
      />

      {/* ---------------------------------------------------------- top UI */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-[1200] p-3">
        <div className="mx-auto flex w-full max-w-[430px] flex-col gap-2">
          <div className="pointer-events-auto flex items-center gap-2">
            <div className="brutal-sm flex flex-1 items-center gap-2 rounded-2xl bg-white px-3 py-2">
              <span className="grid h-8 w-8 place-items-center rounded-xl border-2 border-ink bg-gold text-base">
                🗺️
              </span>
              <div className="min-w-0 flex-1 leading-none">
                <p className="font-display text-[15px] font-extrabold">StickerMap</p>
                <p className="truncate text-[10.5px] font-bold text-ink-soft/70">
                  {results.length} locales · Ayacucho, Perú
                </p>
              </div>
              <PlanChip plan={plan.id} />
            </div>
            <button
              onClick={() => setBillingOpen(true)}
              title="Mi suscripción y facturas"
              className="brutal-sm grid h-[46px] w-[46px] place-items-center rounded-2xl bg-white text-lg press"
            >
              👤
            </button>
            <button
              onClick={() => setPanelOpen(true)}
              title="Panel del comercio"
              className="brutal-sm grid h-[46px] w-[46px] place-items-center rounded-2xl bg-plum text-lg text-white press"
            >
              📊
            </button>
          </div>

          <SearchBar
            query={query}
            onQuery={setQuery}
            category={category}
            onCategory={setCategory}
            sort={sort}
            onSort={setSort}
            count={results.length}
            total={businesses.filter((b) => b.active).length}
            openOnly={openOnly}
            onOpenOnly={setOpenOnly}
            onFit={() => mapRef.current?.fit(results.map((b) => [b.lat, b.lng] as [number, number]))}
          />

          <div className="pointer-events-auto flex flex-wrap items-center gap-2">
            <button
              onClick={() => setFavOnly(!favOnly)}
              className={cn(
                "brutal-sm rounded-full px-3 py-1.5 font-display text-[12px] font-bold press",
                favOnly ? "bg-coral text-white" : "bg-white text-ink"
              )}
            >
              {favOnly ? "❤️" : "🤍"} Favoritos ({favorites.length})
            </button>
            <button
              onClick={() => setShowList(!showList)}
              className="brutal-sm rounded-full bg-white px-3 py-1.5 font-display text-[12px] font-bold press lg:hidden"
            >
              {showList ? "✕ Cerrar" : `📋 Lista (${results.length})`}
            </button>
            {subscription?.status === "trialing" && (
              <button
                onClick={() => openCheckout(subscription.plan)}
                className="brutal-sm shine flex items-center gap-1.5 rounded-full bg-gold px-3 py-1.5 font-display text-[12px] font-extrabold press"
              >
                ⏳ Prueba Gold: {daysLeft(subscription.currentPeriodEnd)} días · Activar
              </button>
            )}
            {subscription?.cancelAtPeriodEnd && (
              <span className="brutal-sm rounded-full bg-white px-3 py-1.5 font-display text-[12px] font-bold">
                ⚠️ Cancela en {daysLeft(subscription.currentPeriodEnd)}d
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------- results list */}
      <div
        className={cn(
          "no-bar absolute z-[1100] overflow-y-auto rounded-3xl border-[3px] border-ink bg-white/95 shadow-[5px_6px_0_#14141b] backdrop-blur",
          "inset-x-3 bottom-24 max-h-[55vh] lg:inset-y-auto lg:left-3 lg:right-auto lg:top-[212px] lg:bottom-20 lg:w-[310px] lg:max-h-none",
          showList ? "block" : "hidden lg:block"
        )}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b-2 border-ink/10 bg-white/95 px-3 py-2 backdrop-blur">
          <p className="font-display text-[13px] font-extrabold">Resultados · {results.length}</p>
          <span className="text-[10.5px] font-bold uppercase text-ink-soft/60">
            {mine.length}/{plan.maxLocations} míos
          </span>
        </div>
        <div className="divide-y-2 divide-ink/5">
          {results.length === 0 && (
            <p className="p-5 text-center text-[13px] font-semibold text-ink-soft/70">
              No encontramos nada con esos filtros. Prueba otra categoría 🤔
            </p>
          )}
          {results.map((b) => {
            const dist = userPos ? distanceM(userPos, b) : null;
            return (
              <button
                key={b.id}
                onClick={() => select(b)}
                className={cn(
                  "flex w-full items-center gap-2.5 p-2.5 text-left transition-colors",
                  selectedId === b.id ? "bg-plum/10" : "hover:bg-cream"
                )}
              >
                <img
                  src={b.img}
                  alt={b.name}
                  className="h-11 w-11 shrink-0 rounded-xl border-2 border-ink object-cover"
                  onError={(e) => {
                    e.currentTarget.onerror = null;
                    e.currentTarget.src = FALLBACK_IMG;
                  }}
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <p className="truncate font-display text-[13.5px] font-extrabold leading-none">
                      {b.name}
                    </p>
                    {(b.boostedUntil ?? 0) > Date.now() && <span title="Impulsado">🔥</span>}
                  </div>
                  <p className="mt-0.5 truncate text-[11px] font-semibold text-ink-soft">
                    {CAT_ICONS[b.category]} {b.category} · ⭐ {b.rating.toFixed(1)} ·{" "}
                    {isOpenNow(b.hours) ? "🟢" : "⚪"}
                    {dist !== null && ` · ${distanceLabel(dist)}`}
                  </p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <Stars value={b.rating} size={10} />
                    <span className="text-[10px] font-bold text-ink-soft/60">
                      👁️ {moneyShort(b.views)}
                    </span>
                    {b.ownerId === user?.id && (
                      <span className="rounded-full border border-ink px-1.5 text-[9px] font-extrabold uppercase">
                        tuyo
                      </span>
                    )}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* ------------------------------------------------- right controls */}
      <div className="absolute right-3 top-[212px] z-[1200] flex flex-col gap-2">
        <button
          onClick={() =>
            setMapStyle((s) => (s === "voyager" ? "dark" : s === "dark" ? "positron" : "voyager"))
          }
          title={`Estilo del mapa: ${MAP_STYLES[mapStyle].label}`}
          className="brutal-sm grid h-11 w-11 place-items-center rounded-2xl bg-white text-base press"
        >
          {MAP_STYLES[mapStyle].icon}
        </button>
        <button
          onClick={() => openEditor(null)}
          title="Registrar mi local"
          className="brutal-sm grid h-11 w-11 place-items-center rounded-2xl bg-gold text-lg press"
        >
          ➕
        </button>
      </div>

      <div className="absolute bottom-4 right-3 z-[1200] flex flex-col items-end gap-2">
        <button
          onClick={() => mapRef.current?.fit(results.map((b) => [b.lat, b.lng] as [number, number]))}
          title="Encuadrar resultados"
          className="brutal-sm hidden rounded-2xl bg-white px-3 py-2 font-display text-[12px] font-bold press sm:block"
        >
          🎯 Encuadrar {results.length}
        </button>
        <button
          onClick={locate}
          title="Mi ubicación"
          className="brutal-sm grid h-14 w-14 place-items-center rounded-full bg-white press"
        >
          {locating ? (
            <span className="spin-slow text-xl">◌</span>
          ) : (
            <svg
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="#14141b"
              strokeWidth="2.2"
              strokeLinecap="round"
            >
              <circle cx="12" cy="12" r="9" />
              <circle cx="12" cy="12" r="3" fill="#14141b" />
              <path d="M12 1v3M12 20v3M1 12h3M20 12h3" />
            </svg>
          )}
        </button>
      </div>

      {/* -------------------------------------------------------- overlays */}
      <DetailSheet
        business={selected}
        userPos={userPos}
        onClose={() => setSelectedId(null)}
        onEdit={openEditor}
        onUpgrade={() => openCheckout(selected?.plan === "free" ? "gold" : "platinum")}
      />

      <BusinessEditor
        open={editorOpen}
        onClose={() => {
          setEditorOpen(false);
          setEditing(null);
          setPickMode(false);
        }}
        editing={editing}
        userPos={userPos}
        onPickMode={setPickMode}
        picking={pickMode}
        picked={picked}
        onPreview={setPreview}
        onUpgrade={(p) => {
          setEditorOpen(false);
          openCheckout(p);
        }}
      />

      <MerchantPanel
        open={panelOpen}
        onClose={() => setPanelOpen(false)}
        onEdit={(b) => {
          setPanelOpen(false);
          openEditor(b);
        }}
        onView={(b) => {
          setPanelOpen(false);
          select(b);
        }}
        onAdd={() => {
          setPanelOpen(false);
          openEditor(null);
        }}
        onUpgrade={() => openCheckout(plan.id === "free" ? "gold" : "platinum")}
      />

      <CheckoutModal
        open={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        initialPlan={checkoutPlan}
        onFinished={() => setBillingOpen(true)}
      />

      <BillingModal
        open={billingOpen}
        onClose={() => setBillingOpen(false)}
        onChangePlan={(p) => openCheckout(p ?? (plan.id === "free" ? "gold" : "platinum"))}
      />

      {!onboarded && (
        <Welcome
          onExplore={() => finishOnboarding()}
          onPlans={() => {
            finishOnboarding();
            setCheckoutOpen(true);
          }}
        />
      )}

      <Toasts />

      <div className="pointer-events-none absolute bottom-4 left-16 z-[1100] hidden rounded-2xl border-2 border-ink bg-white/90 px-3 py-2 backdrop-blur sm:block">
        <p className="mb-1 font-display text-[10px] font-extrabold uppercase tracking-wide text-ink-soft/70">
          Visibilidad por plan
        </p>
        <div className="flex items-center gap-3">
          {(["free", "gold", "platinum"] as PlanId[]).map((p) => (
            <span key={p} className="flex items-center gap-1.5 text-[11px] font-bold">
              <span
                className="h-3.5 w-3.5 rounded-full border-2 border-ink"
                style={{ background: PLANS[p].markerBg }}
              />
              {PLANS[p].name}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
