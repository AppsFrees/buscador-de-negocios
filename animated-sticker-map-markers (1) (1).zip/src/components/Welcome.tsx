import { useState } from "react";
import { PLANS, PLAN_ORDER, priceLabel } from "@/lib/plans";
import { useStore } from "@/lib/store";
import { cn } from "@/utils/cn";
import { Button, inputCls } from "./ui";

export default function Welcome({
  onExplore,
  onPlans,
}: {
  onExplore: () => void;
  onPlans: () => void;
}) {
  const { signIn, toast } = useStore();
  const [step, setStep] = useState<0 | 1>(0);
  const [form, setForm] = useState({ name: "", email: "", businessName: "" });

  return (
    <div className="fixed inset-0 z-[4000] flex items-center justify-center overflow-y-auto bg-[radial-gradient(circle_at_20%_10%,#8b5cf6_0%,#14141b_55%)] p-4">
      <div className="pop-in my-auto w-full max-w-[460px]">
        <div className="relative rounded-[32px] border-[3px] border-ink bg-white p-6 shadow-[8px_10px_0_#14141b]">
          <div className="mb-4 flex items-center gap-3">
            <span className="grid h-14 w-14 place-items-center rounded-2xl border-[3px] border-ink bg-gold text-2xl shadow-[3px_3px_0_#14141b]">
              🗺️
            </span>
            <div>
              <h1 className="font-display text-2xl leading-none font-extrabold">StickerMap</h1>
              <p className="text-[12.5px] font-semibold text-ink-soft">
                Tu negocio en el mapa, con marcadores que enamoran.
              </p>
            </div>
          </div>

          {step === 0 ? (
            <>
              <ul className="mb-4 space-y-2">
                {[
                  ["📍", "Marcadores animados estilo sticker con tu foto y nombre"],
                  ["⭐", "Planes Básico, Gold y Platinum con visibilidad real"],
                  ["📊", "Métricas de impresiones, rutas y reseñas de clientes"],
                  ["🔥", "Impulsos de 30 min para destacar sobre la competencia"],
                ].map(([icon, text]) => (
                  <li key={text} className="flex items-start gap-2">
                    <span className="grid h-7 w-7 shrink-0 place-items-center rounded-xl border-2 border-ink bg-cream text-sm">
                      {icon}
                    </span>
                    <span className="text-[13px] font-semibold text-ink-soft">{text}</span>
                  </li>
                ))}
              </ul>

              <div className="mb-4 grid grid-cols-3 gap-2">
                {PLAN_ORDER.map((id) => (
                  <div
                    key={id}
                    className={cn(
                      "rounded-2xl border-[3px] p-2 text-center",
                      id === "platinum" ? "border-ink bg-plum/10" : "border-ink/15 bg-cream"
                    )}
                  >
                    <div
                      className="mx-auto mb-1 grid h-8 w-8 place-items-center rounded-full border-2 border-ink text-[11px] font-black"
                      style={{ background: PLANS[id].markerBg }}
                    >
                      {PLANS[id].crown ? "👑" : id === "gold" ? "★" : "•"}
                    </div>
                    <p className="font-display text-[12px] font-extrabold leading-none">
                      {PLANS[id].name}
                    </p>
                    <p className="text-[10px] font-bold text-ink-soft">
                      {priceLabel(id, "monthly")}
                    </p>
                  </div>
                ))}
              </div>

              <Button size="lg" className="w-full" onClick={() => setStep(1)}>
                Empezar con 7 días de Gold gratis
              </Button>
              <button
                onClick={onExplore}
                className="mt-2 w-full rounded-xl py-2 font-display text-[13px] font-bold text-ink-soft underline decoration-plum decoration-2 press"
              >
                Solo explorar el mapa
              </button>
            </>
          ) : (
            <>
              <div className="space-y-3">
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Tu nombre"
                  className={inputCls}
                />
                <input
                  value={form.businessName}
                  onChange={(e) => setForm({ ...form, businessName: e.target.value })}
                  placeholder="Nombre de tu negocio"
                  className={inputCls}
                />
                <input
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="correo@negocio.com"
                  className={inputCls}
                />
              </div>
              <Button
                size="lg"
                className="mt-4 w-full"
                onClick={() => {
                  if (form.name.trim().length < 2 || !form.email.includes("@")) {
                    toast({
                      title: "Faltan datos",
                      message: "Escribe tu nombre y un correo válido.",
                      variant: "warning",
                    });
                    return;
                  }
                  signIn(
                    form.name.trim(),
                    form.email.trim(),
                    form.businessName.trim() || form.name.trim()
                  );
                  toast({
                    title: "¡Bienvenido a StickerMap!",
                    message: "Tienes 7 días de plan Gold de prueba.",
                    variant: "success",
                  });
                  onExplore();
                }}
              >
                Crear mi cuenta y probar Gold
              </Button>
              <button
                onClick={() => setStep(0)}
                className="mt-2 w-full py-1 font-display text-[12px] font-bold text-ink-soft press"
              >
                ← Volver
              </button>
              <p className="mt-3 text-center text-[11px] font-semibold text-ink-soft/70">
                Demo sin pagos reales · ver planes y precios{" "}
                <button onClick={onPlans} className="underline decoration-plum decoration-2">
                  aquí
                </button>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
