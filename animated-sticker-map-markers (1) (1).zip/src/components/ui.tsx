import { useEffect, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { PLANS } from "@/lib/plans";
import type { PlanId } from "@/lib/types";

/* ------------------------------------------------------------------ button */
type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "dark" | "gold" | "ghost" | "danger" | "white";
  size?: "sm" | "md" | "lg";
};

const VARIANTS: Record<string, string> = {
  primary: "bg-plum text-white hover:bg-plum-deep",
  dark: "bg-ink text-white hover:bg-ink-soft",
  gold: "bg-gold text-ink hover:bg-gold-deep",
  white: "bg-white text-ink hover:bg-cream",
  ghost: "bg-transparent text-ink border-transparent shadow-none hover:bg-black/5",
  danger: "bg-coral text-white hover:bg-red-600",
};

const SIZES: Record<string, string> = {
  sm: "px-3 py-1.5 text-xs rounded-lg text-[13px]",
  md: "px-4 py-2.5 text-sm rounded-xl",
  lg: "px-5 py-3.5 text-base rounded-2xl",
};

export function Button({ variant = "primary", size = "md", className, ...rest }: BtnProps) {
  return (
    <button
      {...rest}
      className={cn(
        "brutal-sm press inline-flex items-center justify-center gap-2 font-display font-bold tracking-tight",
        VARIANTS[variant],
        SIZES[size],
        className
      )}
    />
  );
}

/* -------------------------------------------------------------------- modal */
export function Modal({
  open,
  onClose,
  children,
  size = "md",
  labelledBy,
}: {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  size?: "sm" | "md" | "lg" | "xl";
  labelledBy?: string;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  const widths = {
    sm: "max-w-sm",
    md: "max-w-lg",
    lg: "max-w-3xl",
    xl: "max-w-5xl",
  }[size];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby={labelledBy}
      className="fixed inset-0 z-[3000] flex items-start justify-center overflow-y-auto bg-ink/70 p-3 backdrop-blur-sm sm:items-center sm:p-6 hide-fade"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className={cn(
          "pop-in relative my-auto w-full rounded-3xl border-[3px] border-ink bg-white shadow-[6px_8px_0_#14141b]",
          widths
        )}
      >
        <button
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute -right-3 -top-3 z-20 grid h-10 w-10 place-items-center rounded-full border-2 border-ink bg-white text-lg font-black shadow-[2px_2px_0_#14141b] press"
        >
          ✕
        </button>
        {children}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------- fields */
export function Field({
  label,
  hint,
  error,
  children,
  className,
}: {
  label: string;
  hint?: string;
  error?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="mb-1 flex items-baseline justify-between gap-2">
        <span className="font-display text-[13px] font-bold text-ink">{label}</span>
        {hint && <span className="text-[11px] font-medium text-ink-soft/70">{hint}</span>}
      </span>
      {children}
      {error && <span className="mt-1 block text-[11px] font-bold text-coral">{error}</span>}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border-2 border-ink/20 bg-cream px-3 py-2.5 text-sm font-medium text-ink outline-none transition-colors placeholder:text-ink-soft/50 focus:border-ink";

/* ------------------------------------------------------------------ badges */
export function PlanChip({ plan, className }: { plan: PlanId; className?: string }) {
  const p = PLANS[plan];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border-2 border-ink px-2 py-0.5 font-display text-[11px] font-extrabold uppercase tracking-wide",
        p.chip,
        className
      )}
    >
      {p.name}
    </span>
  );
}

export function Stars({
  value,
  size = 14,
  onRate,
  className,
}: {
  value: number;
  size?: number;
  onRate?: (v: number) => void;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-[2px]", className)}>
      {[1, 2, 3, 4, 5].map((i) => {
        const fill = Math.max(0, Math.min(1, value - (i - 1)));
        return (
          <span
            key={i}
            role={onRate ? "button" : undefined}
            aria-label={onRate ? `${i} estrellas` : undefined}
            onClick={onRate ? () => onRate(i) : undefined}
            className={cn("relative inline-block", onRate && "cursor-pointer hover:scale-125 transition-transform")}
            style={{ width: size, height: size, fontSize: size, lineHeight: `${size}px` }}
          >
            <span className="absolute inset-0 text-ink/20">★</span>
            <span
              className="absolute inset-0 overflow-hidden text-amber-500"
              style={{ width: `${fill * 100}%`, textShadow: "0.5px 0.5px 0 #14141b" }}
            >
              ★
            </span>
          </span>
        );
      })}
    </span>
  );
}

/* ------------------------------------------------------------------- charts */
export function Sparkline({
  data,
  height = 48,
  stroke = "#8b5cf6",
  fill = "rgba(139,92,246,0.16)",
  labels,
}: {
  data: number[];
  height?: number;
  stroke?: string;
  fill?: string;
  labels?: boolean;
}) {
  if (!data.length) return null;
  const w = 300;
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const span = Math.max(1, max - min);
  const step = w / Math.max(1, data.length - 1);
  const pts = data.map((d, i) => [i * step, height - ((d - min) / span) * (height - 6) - 3]);
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const area = `${path} L${w},${height} L0,${height} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${height}`} className="w-full" preserveAspectRatio="none">
      <path d={area} fill={fill} />
      <path d={path} fill="none" stroke={stroke} strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r={3.5} fill={stroke} stroke="#fff" strokeWidth={1.5} />
      {labels && null}
    </svg>
  );
}

export function Bars({ data, color = "#ffc93c" }: { data: number[]; color?: string }) {
  const max = Math.max(...data, 1);
  return (
    <div className="flex h-24 items-end gap-1">
      {data.map((d, i) => (
        <div
          key={i}
          title={`${d}`}
          className="flex-1 rounded-t-[4px] border-b-2 border-ink/10"
          style={{ height: `${Math.max(6, (d / max) * 100)}%`, background: color }}
        />
      ))}
    </div>
  );
}

export function StatCard({
  label,
  value,
  delta,
  icon,
  children,
}: {
  label: string;
  value: string;
  delta?: string;
  icon?: string;
  children?: ReactNode;
}) {
  const up = delta?.startsWith("+");
  return (
    <div className="brutal rounded-2xl bg-white p-3">
      <div className="flex items-center justify-between">
        <span className="font-display text-[11px] font-bold uppercase tracking-wide text-ink-soft/70">
          {icon} {label}
        </span>
        {delta && (
          <span
            className={cn(
              "rounded-full border-2 border-ink px-1.5 text-[10px] font-black",
              up ? "bg-mint text-ink" : "bg-coral text-white"
            )}
          >
            {delta}
          </span>
        )}
      </div>
      <p className="font-display text-2xl font-extrabold leading-tight text-ink">{value}</p>
      {children}
    </div>
  );
}

export function Progress({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("h-2.5 w-full overflow-hidden rounded-full border-2 border-ink bg-white", className)}>
      <div
        className="h-full rounded-full bg-gradient-to-r from-gold to-plum transition-all duration-500"
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

export function Divider({ label }: { label?: string }) {
  if (!label) return <div className="my-4 h-0.5 rounded-full bg-ink/10" />;
  return (
    <div className="my-4 flex items-center gap-3">
      <div className="h-0.5 flex-1 rounded-full bg-ink/10" />
      <span className="font-display text-[11px] font-bold uppercase tracking-wider text-ink-soft/60">
        {label}
      </span>
      <div className="h-0.5 flex-1 rounded-full bg-ink/10" />
    </div>
  );
}
