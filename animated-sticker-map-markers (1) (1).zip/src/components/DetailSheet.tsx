import { useEffect, useMemo, useRef, useState } from "react";
import { PLANS } from "@/lib/plans";
import { FALLBACK_IMG } from "@/lib/seed";
import { useStore } from "@/lib/store";
import type { Business } from "@/lib/types";
import {
  WEEKDAYS,
  distanceLabel,
  distanceM,
  hoursLabel,
  isOpenNow,
  moneyShort,
  nextChangeLabel,
  relative,
  todayIndex,
} from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Button, PlanChip, Progress, Stars } from "./ui";

export default function DetailSheet({
  business,
  userPos,
  onClose,
  onEdit,
  onUpgrade,
}: {
  business: Business | null;
  userPos: { lat: number; lng: number } | null;
  onClose: () => void;
  onEdit: (b: Business) => void;
  onUpgrade: () => void;
}) {
  const {
    reviews,
    addReview,
    toggleFavorite,
    favorites,
    track,
    user,
    subscription,
    boost,
  } = useStore();
  const [tab, setTab] = useState<"info" | "resenas">("info");
  const [myRating, setMyRating] = useState(0);
  const [myText, setMyText] = useState("");
  const startY = useRef<number | null>(null);
  const tracked = useRef<string | null>(null);

  useEffect(() => {
    setTab("info");
    setMyRating(0);
    setMyText("");
    tracked.current = null;
  }, [business?.id]);

  useEffect(() => {
    if (business && tracked.current !== business.id) {
      tracked.current = business.id;
      track(business.id, "views");
    }
  }, [business, track]);

  const bizReviews = useMemo(
    () => reviews.filter((r) => r.businessId === business?.id).slice(0, 6),
    [reviews, business?.id]
  );

  if (!business) return null;

  const plan = PLANS[business.plan];
  const open = isOpenNow(business.hours);
  const dist = userPos ? distanceM(userPos, business) : null;
  const isOwner = business.ownerId === user?.id;
  const boosted = (business.boostedUntil ?? 0) > Date.now();
  const fav = favorites.includes(business.id);

  const go = () => {
    track(business.id, "routeClicks");
    const url = userPos
      ? `https://www.google.com/maps/dir/?api=1&origin=${userPos.lat},${userPos.lng}&destination=${business.lat},${business.lng}&travelmode=walking`
      : `https://www.google.com/maps/search/?api=1&query=${business.lat},${business.lng}`;
    window.open(url, "_blank", "noopener");
  };

  const share = async () => {
    const text = `${business.name} en StickerMap · ${business.address}`;
    try {
      if (navigator.share) await navigator.share({ title: business.name, text });
      else await navigator.clipboard.writeText(text);
    } catch {
      /* user cancelled */
    }
  };

  return (
    <div
      className="fixed inset-0 z-[2500] flex items-end justify-center bg-ink/60 backdrop-blur-sm sm:items-center sm:p-4 hide-fade"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="slide-up relative flex max-h-[92vh] w-full max-w-[440px] flex-col overflow-hidden rounded-t-[28px] border-[3px] border-b-0 border-ink bg-white shadow-[0_-6px_0_#14141b] sm:rounded-[28px] sm:border-b-[3px] sm:shadow-[6px_8px_0_#14141b]"
        role="dialog"
        aria-label={business.name}
      >
        {/* swipe handle + close */}
        <button
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute right-3 top-3 z-20 grid h-9 w-9 place-items-center rounded-full border-2 border-ink bg-white font-black shadow-[2px_2px_0_#14141b] press"
        >
          ✕
        </button>

        {/* image */}
        <div
          className="relative h-52 shrink-0 sm:h-60"
          onTouchStart={(e) => (startY.current = e.touches[0].clientY)}
          onTouchMove={(e) => {
            if (startY.current === null) return;
            if (e.touches[0].clientY - startY.current > 70) {
              startY.current = null;
              onClose();
            }
          }}
          onTouchEnd={() => (startY.current = null)}
        >
          <img
            src={business.img}
            alt={business.name}
            className="h-full w-full object-cover"
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = FALLBACK_IMG;
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/85 via-ink/10 to-transparent" />
          {boosted && (
            <span className="absolute left-3 top-3 rounded-full border-2 border-ink bg-coral px-2.5 py-1 font-display text-[11px] font-extrabold text-white shadow-[2px_2px_0_#14141b]">
              🔥 Impulsado ahora
            </span>
          )}
          <div className="absolute inset-x-4 bottom-3">
            <div className="mb-1 flex flex-wrap items-center gap-1.5">
              <PlanChip plan={business.plan} />
              {business.verified && (
                <span className="rounded-full border-2 border-ink bg-white px-2 py-0.5 font-display text-[10px] font-extrabold uppercase">
                  ✔ Verificado
                </span>
              )}
            </div>
            <h2 className="font-display text-[28px] leading-none font-extrabold text-white drop-shadow-[0_2px_0_rgba(0,0,0,0.35)]">
              {business.name}
            </h2>
          </div>
        </div>

        {/* tabs */}
        <div className="flex gap-2 border-b-2 border-ink/10 px-4 pt-3">
          {(["info", "resenas"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                "relative pb-2 font-display text-sm font-bold capitalize transition-colors",
                tab === t ? "text-ink" : "text-ink-soft/60 hover:text-ink"
              )}
            >
              {t === "resenas" ? `Reseñas (${business.ratingCount})` : "Información"}
              {tab === t && (
                <span className="absolute inset-x-0 -bottom-[2px] h-1 rounded-full bg-plum" />
              )}
            </button>
          ))}
        </div>

        {/* body */}
        <div className="no-bar flex-1 overflow-y-auto px-4 py-4">
          {tab === "info" ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="brutal-sm flex items-center gap-1 rounded-lg bg-gold px-2 py-1 font-display text-[12px] font-extrabold">
                  ⭐ {business.rating.toFixed(1)}
                  <span className="font-sans text-[11px] font-semibold opacity-70">
                    ({business.ratingCount})
                  </span>
                </span>
                <span
                  className={cn(
                    "brutal-sm rounded-lg px-2 py-1 font-display text-[12px] font-extrabold",
                    open ? "bg-mint text-ink" : "bg-ink/10 text-ink"
                  )}
                >
                  {open ? "Abierto ahora" : "Cerrado"}
                </span>
                {dist !== null && (
                  <span className="brutal-sm rounded-lg bg-white px-2 py-1 font-display text-[12px] font-extrabold">
                    📍 {distanceLabel(dist)}
                  </span>
                )}
                <span className="brutal-sm rounded-lg bg-white px-2 py-1 font-display text-[12px] font-extrabold">
                  👁️ {moneyShort(business.views)}
                </span>
              </div>

              <p className="text-[13.5px] font-medium leading-relaxed text-ink-soft">
                {business.desc}
              </p>

              <dl className="grid grid-cols-1 gap-2">
                <Row icon="📌" label={business.address} />
                <Row icon="🕒" label={`${hoursLabel(business.hours[todayIndex()])} · ${nextChangeLabel(business.hours)}`} />
                {business.phone && (
                  <Row
                    icon="📞"
                    label={business.phone}
                    href={`tel:${business.phone.replace(/\s/g, "")}`}
                  />
                )}
              </dl>

              {business.promo && (
                <div className="brutal-sm flex items-center justify-between gap-2 rounded-2xl bg-plum/10 px-3 py-2">
                  <div>
                    <p className="font-display text-[13px] font-extrabold text-plum-deep">
                      🎟️ {business.promo.label}
                    </p>
                    <p className="text-[11px] font-semibold text-ink-soft">
                      Código: <b>{business.promo.code}</b>
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="dark"
                    onClick={() => navigator.clipboard?.writeText(business.promo!.code)}
                  >
                    Copiar
                  </Button>
                </div>
              )}

              <div>
                <p className="mb-1.5 font-display text-[12px] font-bold uppercase tracking-wide text-ink-soft/70">
                  Horario semanal
                </p>
                <div className="grid grid-cols-2 gap-1">
                  {business.hours.map((h, i) => (
                    <div
                      key={i}
                      className={cn(
                        "flex items-center justify-between rounded-lg px-2 py-1 text-[11.5px] font-semibold",
                        i === todayIndex() ? "bg-ink text-white" : "bg-ink/5 text-ink-soft"
                      )}
                    >
                      <span>{WEEKDAYS[i]}</span>
                      <span>{hoursLabel(h)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {isOwner && (
                <div className="brutal rounded-2xl bg-cream p-3">
                  <p className="mb-2 font-display text-sm font-extrabold">
                    Panel del propietario · Plan {plan.name}
                  </p>
                  <Progress value={(business.views / Math.max(1, plan.maxLocations * 900)) * 100} />
                  <p className="mt-1.5 text-[11px] font-semibold text-ink-soft">
                    {moneyShort(business.views)} impresiones · {business.routeClicks} rutas abiertas
                    {" · "}
                    {moneyShort(Math.round((business.routeClicks / Math.max(1, business.views)) * 100))}% CTR
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button size="sm" variant="white" onClick={() => onEdit(business)}>
                      ✏️ Editar ficha
                    </Button>
                    <Button
                      size="sm"
                      variant="gold"
                      disabled={boosted || (subscription?.addonBoosts ?? 0) <= 0}
                      onClick={() => boost(business.id)}
                    >
                      🔥 Impulsar 30 min ({subscription?.addonBoosts ?? 0})
                    </Button>
                    {business.plan !== "platinum" && (
                      <Button size="sm" variant="primary" onClick={onUpgrade}>
                        ⬆️ Subir plan
                      </Button>
                    )}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap gap-2">
                <Button className="flex-1" variant="primary" onClick={go}>
                  🧭 Cómo llegar
                </Button>
                <Button variant="white" onClick={() => toggleFavorite(business.id)} title="Favorito">
                  {fav ? "❤️" : "🤍"}
                </Button>
                <Button variant="white" onClick={share} title="Compartir">
                  🔗
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="brutal-sm rounded-2xl bg-cream p-3">
                <p className="mb-2 font-display text-sm font-extrabold">Deja tu reseña</p>
                <Stars value={myRating} size={26} onRate={setMyRating} />
                <textarea
                  value={myText}
                  onChange={(e) => setMyText(e.target.value)}
                  placeholder="¿Cómo fue tu experiencia?"
                  className="mt-2 h-20 w-full resize-none rounded-xl border-2 border-ink/20 bg-white px-3 py-2 text-[13px] font-medium outline-none focus:border-ink"
                />
                <Button
                  size="sm"
                  className="mt-2 w-full"
                  disabled={myRating === 0}
                  onClick={() => {
                    addReview(business.id, myRating, myText || "¡Muy recomendado!");
                    setMyRating(0);
                    setMyText("");
                  }}
                >
                  Publicar reseña
                </Button>
              </div>

              {bizReviews.length === 0 && (
                <p className="py-6 text-center text-sm font-semibold text-ink-soft/70">
                  Todavía no hay reseñas. ¡Sé el primero!
                </p>
              )}
              {bizReviews.map((r) => (
                <div key={r.id} className="rounded-2xl border-2 border-ink/10 bg-white p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-display text-[13px] font-extrabold">{r.author}</span>
                    <span className="text-[11px] font-semibold text-ink-soft/70">
                      {relative(r.date)}
                    </span>
                  </div>
                  <Stars value={r.rating} />
                  <p className="mt-1 text-[13px] font-medium leading-snug text-ink-soft">{r.text}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({
  icon,
  label,
  href,
}: {
  icon: string;
  label: string;
  href?: string;
}) {
  return (
    <div className="brutal-sm flex items-center gap-2 rounded-xl bg-white px-3 py-2">
      <span>{icon}</span>
      {href ? (
        <a href={href} className="text-[13px] font-bold text-ink underline decoration-plum decoration-2">
          {label}
        </a>
      ) : (
        <span className="text-[13px] font-semibold text-ink-soft">{label}</span>
      )}
    </div>
  );
}
