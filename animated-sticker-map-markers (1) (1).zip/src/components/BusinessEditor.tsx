import { useEffect, useState } from "react";
import { PLANS } from "@/lib/plans";
import { useMyBusinesses, useStore } from "@/lib/store";
import type { Business, Category, PlanId } from "@/lib/types";
import { distanceLabel, defaultHours } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Button, Field, inputCls, PlanChip, Progress } from "./ui";
import { CATEGORIES } from "./SearchBar";

const PRESETS = [
  {
    label: "Café",
    img: "https://images.unsplash.com/photo-1497935586351-b67a49e012bf?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Comida",
    img: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Tienda",
    img: "https://images.unsplash.com/photo-1604719312566-8912e9227c6a?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Postres",
    img: "https://images.unsplash.com/photo-1557142046-c704a3adf364?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Salud",
    img: "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Hotel",
    img: "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Servicios",
    img: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?auto=format&fit=crop&w=480&q=70",
  },
  {
    label: "Fachada",
    img: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=480&q=70",
  },
];

const CENTER = { lat: -13.161, lng: -74.2236 };

export default function BusinessEditor({
  open,
  onClose,
  editing,
  userPos,
  onPickMode,
  picking,
  onUpgrade,
  onPreview,
  picked,
}: {
  open: boolean;
  onClose: () => void;
  editing: Business | null;
  userPos: { lat: number; lng: number } | null;
  onPickMode: (on: boolean) => void;
  picking: boolean;
  onUpgrade: (plan: PlanId) => void;
  onPreview: (p: { lat: number; lng: number; plan: PlanId } | null) => void;
  picked: { lat: number; lng: number; key: number } | null;
}) {
  const { addBusiness, updateBusiness, deleteBusiness, subscription, toast, user } = useStore();
  const mine = useMyBusinesses();
  const planId = subscription?.plan ?? "free";
  const plan = PLANS[planId];
  const atLimit = !editing && mine.length >= plan.maxLocations;

  const [form, setForm] = useState({
    name: "",
    category: "Café" as Category,
    desc: "",
    phone: "",
    address: "",
    img: PRESETS[0].img,
    lat: CENTER.lat,
    lng: CENTER.lng,
    promoCode: "",
    promoLabel: "",
    promoOff: 10,
    active: true,
    hours: defaultHours(),
  });
  const [err, setErr] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) {
      onPreview(null);
      return;
    }
    setErr({});
    onPickMode(false);
    if (editing) {
      setForm({
        name: editing.name,
        category: editing.category,
        desc: editing.desc,
        phone: editing.phone,
        address: editing.address,
        img: editing.img,
        lat: editing.lat,
        lng: editing.lng,
        promoCode: editing.promo?.code ?? "",
        promoLabel: editing.promo?.label ?? "",
        promoOff: editing.promo?.percentOff ?? 10,
        active: editing.active,
        hours: editing.hours,
      });
    } else {
      setForm((f) => ({
        ...f,
        name: "",
        desc: "",
        phone: "",
        address: "",
        promoCode: "",
        promoLabel: "",
        active: true,
        img: PRESETS[0].img,
        lat: userPos?.lat ?? CENTER.lat,
        lng: userPos?.lng ?? CENTER.lng,
        hours: defaultHours(),
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing?.id]);

  useEffect(() => {
    if (open) onPreview({ lat: form.lat, lng: form.lng, plan: planId });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, form.lat, form.lng, planId]);

  /* coordinates tapped on the map while "aim mode" is on */
  useEffect(() => {
    if (!picked || !open) return;
    setForm((f) => ({ ...f, lat: picked.lat, lng: picked.lng }));
    toast({
      title: "Punto actualizado",
      message: `${picked.lat.toFixed(5)}, ${picked.lng.toFixed(5)}`,
      variant: "success",
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [picked?.key]);

  const submit = () => {
    const e: Record<string, string> = {};
    if (form.name.trim().length < 3) e.name = "Escribe el nombre del negocio.";
    if (form.desc.trim().length < 20) e.desc = "Cuéntanos un poco más (mín. 20 caracteres).";
    if (!form.address.trim()) e.address = "Agrega la dirección.";
    setErr(e);
    if (Object.keys(e).length) return;

    const base = {
      name: form.name.trim(),
      category: form.category,
      desc: form.desc.trim(),
      phone: planId === "free" ? "" : form.phone.trim(),
      address: form.address.trim(),
      img: form.img,
      lat: form.lat,
      lng: form.lng,
      hours: form.hours,
      plan: planId,
      verified: plan.verified,
      active: form.active,
      promo:
        planId === "platinum" && form.promoCode.trim()
          ? {
              code: form.promoCode.trim().toUpperCase(),
              label: form.promoLabel.trim() || "Descuento para usuarios del mapa",
              percentOff: form.promoOff,
            }
          : undefined,
    };

    if (editing) {
      updateBusiness(editing.id, base);
      toast({ title: "Ficha actualizada", message: base.name, variant: "success" });
      onPickMode(false);
      onClose();
      return;
    }

    if (atLimit) {
      toast({
        title: `Límite del plan ${plan.name}`,
        message: `Ya publicaste ${mine.length} de ${plan.maxLocations} marcadores. Sube de plan para añadir más.`,
        variant: "warning",
      });
      return;
    }

    const created = addBusiness(base);
    if (!created) {
      toast({ title: "No se pudo publicar", message: "Revisa tu plan.", variant: "error" });
      return;
    }
    onPickMode(false);
    onClose();
    toast({
      title: "¡Tu local está en el mapa!",
      message: `${base.name} · marcador ${plan.name.toLowerCase()}`,
      variant: "success",
    });
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[3050] flex items-start justify-center overflow-y-auto bg-ink/70 p-3 backdrop-blur-sm sm:items-center sm:p-6 hide-fade"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="pop-in relative my-auto w-full max-w-[520px] overflow-hidden rounded-3xl border-[3px] border-ink bg-white shadow-[6px_8px_0_#14141b]">
        <button
          onClick={() => {
            onPickMode(false);
            onClose();
          }}
          aria-label="Cerrar"
          className="absolute -right-3 -top-3 z-20 grid h-10 w-10 place-items-center rounded-full border-2 border-ink bg-white text-lg font-black shadow-[2px_2px_0_#14141b] press"
        >
          ✕
        </button>

        <div className="flex items-center gap-3 border-b-2 border-ink/10 bg-cream px-5 py-4">
          <span className="grid h-11 w-11 place-items-center rounded-2xl border-2 border-ink bg-white text-xl shadow-[2px_2px_0_#14141b]">
            {editing ? "✏️" : "📍"}
          </span>
          <div className="flex-1">
            <h2 className="font-display text-lg leading-tight font-extrabold">
              {editing ? "Editar ficha" : "Registrar mi local"}
            </h2>
            <p className="flex items-center gap-1.5 text-[12px] font-semibold text-ink-soft/80">
              {user?.businessName ?? "Tu negocio"} · <PlanChip plan={planId} />
            </p>
          </div>
        </div>

        <div className="no-bar max-h-[64vh] overflow-y-auto px-5 py-4">
          {atLimit && (
            <div className="brutal mb-4 rounded-2xl bg-gold/30 p-3">
              <p className="font-display text-[13px] font-extrabold">
                Límite del plan {plan.name}: {plan.maxLocations} marcador(es)
              </p>
              <Progress value={100} className="mt-1.5" />
              <p className="mt-1.5 text-[12px] font-semibold text-ink-soft">
                {planId === "free"
                  ? "Con Gold publicas hasta 5 locales con marcador dorado."
                  : "Con Platinum publicas hasta 25 locales con corona VIP."}
              </p>
              <Button
                size="sm"
                variant="dark"
                className="mt-2"
                onClick={() => onUpgrade(planId === "free" ? "gold" : "platinum")}
              >
                Ver plan {planId === "free" ? "Gold" : "Platinum"}
              </Button>
            </div>
          )}

          <div className="mb-4 flex items-center gap-3 rounded-2xl border-2 border-dashed border-ink/25 p-3">
            <div
              className="grid h-14 w-14 shrink-0 place-items-center rounded-full border-2 border-ink text-xl"
              style={{ background: plan.markerBg }}
            >
              📍
            </div>
            <div className="min-w-0 flex-1 text-[11.5px] font-semibold text-ink-soft">
              Tu marcador se verá estilo <b>{plan.name}</b> · escala {plan.markerScale}x · flotación
              cada {plan.animSpeed}
              {plan.crown && " · corona VIP"}
              {plan.halo && " · halo animado"}.
            </div>
          </div>

          <div className="space-y-3">
            <Field label="Nombre del negocio" error={err.name}>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Café Wari"
                className={inputCls}
              />
            </Field>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Categoría">
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value as Category })}
                  className={inputCls}
                >
                  {CATEGORIES.filter((c) => c !== "Todos").map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Teléfono" hint={planId === "free" ? "Solo Gold+" : undefined}>
                <input
                  value={form.phone}
                  disabled={planId === "free"}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="+51 966 000 000"
                  className={cn(inputCls, planId === "free" && "opacity-50")}
                />
              </Field>
            </div>

            <Field label="Dirección" error={err.address}>
              <input
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                placeholder="Jr. 28 de Julio 215, Ayacucho"
                className={inputCls}
              />
            </Field>

            <Field label="Descripción" error={err.desc} hint={`${form.desc.length}/300`}>
              <textarea
                value={form.desc}
                maxLength={300}
                onChange={(e) => setForm({ ...form, desc: e.target.value })}
                placeholder="Qué ofreces, qué te hace especial, promociones…"
                className={cn(inputCls, "h-24 resize-none")}
              />
            </Field>

            <Field label="Foto principal">
              <div className="no-bar mb-2 flex gap-2 overflow-x-auto pb-1">
                {PRESETS.map((p) => (
                  <button
                    key={p.label}
                    onClick={() => setForm({ ...form, img: p.img })}
                    className={cn(
                      "relative h-14 w-14 shrink-0 overflow-hidden rounded-xl border-[3px]",
                      form.img === p.img ? "border-ink" : "border-ink/15"
                    )}
                  >
                    <img src={p.img} alt={p.label} className="h-full w-full object-cover" />
                    <span className="absolute inset-x-0 bottom-0 bg-ink/70 py-0.5 text-[9px] font-bold text-white">
                      {p.label}
                    </span>
                  </button>
                ))}
              </div>
              <input
                value={form.img}
                onChange={(e) => setForm({ ...form, img: e.target.value })}
                placeholder="https://… (URL de tu foto)"
                className={inputCls}
              />
            </Field>

            <div className="brutal rounded-2xl bg-cream p-3">
              <p className="mb-2 font-display text-[13px] font-extrabold">📍 Ubicación exacta</p>
              <div className="mb-2 flex flex-wrap gap-2">
                <Button
                  size="sm"
                  variant={picking ? "gold" : "white"}
                  onClick={() => onPickMode(!picking)}
                >
                  {picking ? "🎯 Toca el mapa…" : "🎯 Elegir en el mapa"}
                </Button>
                <Button
                  size="sm"
                  variant="white"
                  onClick={() => {
                    if (userPos) setForm({ ...form, lat: userPos.lat, lng: userPos.lng });
                    else
                      toast({
                        title: "Sin ubicación GPS",
                        message: "Activa tu ubicación o elige el punto en el mapa.",
                        variant: "warning",
                      });
                  }}
                >
                  📡 Usar mi GPS
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input
                  value={form.lat.toFixed(6)}
                  onChange={(e) => setForm({ ...form, lat: Number(e.target.value) || form.lat })}
                  className={cn(inputCls, "font-mono text-[12px]")}
                />
                <input
                  value={form.lng.toFixed(6)}
                  onChange={(e) => setForm({ ...form, lng: Number(e.target.value) || form.lng })}
                  className={cn(inputCls, "font-mono text-[12px]")}
                />
              </div>
              {userPos && (
                <p className="mt-1.5 text-[11px] font-semibold text-ink-soft">
                  A{" "}
                  {distanceLabel(
                    Math.hypot(
                      (form.lat - userPos.lat) * 111000,
                      (form.lng - userPos.lng) * 102000
                    )
                  )}{" "}
                  de tu posición
                </p>
              )}
              {picking && (
                <p className="mt-2 rounded-xl border-2 border-dashed border-ink/30 bg-white px-2 py-1 text-[11px] font-bold">
                  Modo puntería: toca el mapa para mover el marcador.
                </p>
              )}
            </div>

            <div className="brutal rounded-2xl bg-cream p-3">
              <p className="mb-2 font-display text-[13px] font-extrabold">🕒 Horario</p>
              <div className="grid grid-cols-2 gap-2">
                <Field label="Abre">
                  <input
                    type="time"
                    value={`${String(Math.floor(form.hours[1].open / 60)).padStart(2, "0")}:${String(
                      form.hours[1].open % 60
                    ).padStart(2, "0")}`}
                    onChange={(e) => {
                      const [h, m] = e.target.value.split(":").map(Number);
                      if (Number.isNaN(h)) return;
                      setForm({
                        ...form,
                        hours: form.hours.map((d, i) =>
                          i === 0 || d.closed ? d : { ...d, open: h * 60 + m }
                        ),
                      });
                    }}
                    className={inputCls}
                  />
                </Field>
                <Field label="Cierra">
                  <input
                    type="time"
                    value={`${String(Math.floor(form.hours[1].close / 60)).padStart(2, "0")}:${String(
                      form.hours[1].close % 60
                    ).padStart(2, "0")}`}
                    onChange={(e) => {
                      const [h, m] = e.target.value.split(":").map(Number);
                      if (Number.isNaN(h)) return;
                      setForm({
                        ...form,
                        hours: form.hours.map((d, i) =>
                          i === 0 || d.closed ? d : { ...d, close: h * 60 + m }
                        ),
                      });
                    }}
                    className={inputCls}
                  />
                </Field>
              </div>
              <label className="mt-2 flex items-center gap-2 text-[12px] font-semibold">
                <input
                  type="checkbox"
                  className="h-4 w-4 accent-plum"
                  checked={form.hours[0].closed}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      hours: form.hours.map((d, i) =>
                        i === 0 ? { ...d, closed: e.target.checked } : d
                      ),
                    })
                  }
                />
                Cerrado los domingos
              </label>
            </div>

            <div
              className={cn("brutal rounded-2xl p-3", planId === "platinum" ? "bg-plum/10" : "bg-ink/5")}
            >
              <div className="flex items-center justify-between">
                <p className="font-display text-[13px] font-extrabold">🎟️ Cupón en la ficha</p>
                <span className="rounded-full border-2 border-ink bg-white px-2 py-0.5 text-[10px] font-extrabold uppercase">
                  {planId === "platinum" ? "Platinum" : "Bloqueado"}
                </span>
              </div>
              {planId === "platinum" ? (
                <div className="mt-2 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      value={form.promoCode}
                      onChange={(e) => setForm({ ...form, promoCode: e.target.value.toUpperCase() })}
                      placeholder="CAFE10"
                      className={inputCls}
                    />
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={5}
                        max={50}
                        step={5}
                        value={form.promoOff}
                        onChange={(e) => setForm({ ...form, promoOff: Number(e.target.value) })}
                        className="w-full"
                      />
                      <span className="font-display text-sm font-extrabold">-{form.promoOff}%</span>
                    </div>
                  </div>
                  <input
                    value={form.promoLabel}
                    onChange={(e) => setForm({ ...form, promoLabel: e.target.value })}
                    placeholder="Promo para quien te encuentre en el mapa"
                    className={inputCls}
                  />
                </div>
              ) : (
                <>
                  <p className="mt-1 text-[12px] font-semibold text-ink-soft">
                    Publica descuentos exclusivos y mide cuántos usuarios los copian.
                  </p>
                  <Button
                    size="sm"
                    variant="dark"
                    className="mt-2"
                    onClick={() => onUpgrade("platinum")}
                  >
                    Desbloquear con Platinum
                  </Button>
                </>
              )}
            </div>

            <label className="flex items-center justify-between rounded-2xl border-2 border-ink/15 bg-cream px-3 py-2">
              <span className="font-display text-[13px] font-extrabold">
                {form.active ? "🟢 Visible en el mapa" : "⚪ Pausado"}
              </span>
              <input
                type="checkbox"
                className="h-5 w-5 accent-plum"
                checked={form.active}
                onChange={(e) => setForm({ ...form, active: e.target.checked })}
              />
            </label>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 border-t-2 border-ink/10 px-5 py-4">
          {editing && (
            <Button
              variant="danger"
              size="sm"
              onClick={() => {
                deleteBusiness(editing.id);
                onPickMode(false);
                onClose();
                toast({ title: "Ficha eliminada", variant: "info" });
              }}
            >
              Eliminar
            </Button>
          )}
          <div className="flex-1" />
          <Button
            variant="white"
            onClick={() => {
              onPickMode(false);
              onClose();
            }}
          >
            Cancelar
          </Button>
          <Button variant="dark" onClick={submit}>
            {editing ? "Guardar cambios" : "Publicar en el mapa"}
          </Button>
        </div>
      </div>
    </div>
  );
}
