import { useEffect, useImperativeHandle, useMemo, useRef } from "react";
import L from "leaflet";
import { PLANS } from "@/lib/plans";
import { FALLBACK_IMG } from "@/lib/seed";
import type { Business, PlanId } from "@/lib/types";

export type MapHandle = {
  flyTo: (lat: number, lng: number, zoom?: number) => void;
  fit: (points: [number, number][]) => void;
  invalidate: () => void;
};

export type MapStyleId = "voyager" | "positron" | "dark";

export const MAP_STYLES: Record<MapStyleId, { label: string; icon: string; url: string }> = {
  voyager: {
    label: "Calles",
    icon: "🗺️",
    url: "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
  },
  positron: {
    label: "Claro",
    icon: "☀️",
    url: "https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
  },
  dark: {
    label: "Noche",
    icon: "🌙",
    url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
  },
};

const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c] as string)
  );

function stickerIcon(biz: Business, opts: { index: number; active: boolean }) {
  const plan = PLANS[biz.plan];
  const boosted = (biz.boostedUntil ?? 0) > Date.now();
  const bg = boosted ? "#ff5c72" : plan.markerBg;
  const scale = boosted ? plan.markerScale * 1.18 : plan.markerScale;
  const speed = boosted ? "0.7s" : plan.animSpeed;

  const badge = boosted ? "🔥" : plan.badge;
  const html = `
    <div class="sticker-marker ${opts.active ? "is-active" : ""}" style="--sticker-bg:${bg};--sticker-scale:${scale};--anim-speed:${speed};--float-delay:${(
    opts.index * 0.08
  ).toFixed(2)}s">
      <div class="sticker-content">
        <div class="sticker-text" data-label="${esc(biz.name)}">${esc(biz.name)}</div>
        <div class="sticker-bubble ${plan.halo || boosted ? "sticker-halo" : ""}">
          <img class="sticker-img" src="${biz.img}" alt="${esc(biz.name)}" loading="lazy"
               onerror="this.onerror=null;this.src='${FALLBACK_IMG}'"/>
          ${badge ? `<span class="sticker-badge">${badge}</span>` : ""}
          ${plan.crown && !boosted ? `<span class="sticker-crown">👑</span>` : ""}
        </div>
      </div>
    </div>`;

  return L.divIcon({
    html,
    className: "sticker-wrap",
    iconSize: [104, 108],
    iconAnchor: [52, 98],
  });
}

type Props = {
  businesses: Business[];
  selectedId: string | null;
  onSelect: (b: Business) => void;
  userPos: { lat: number; lng: number; accuracy: number } | null;
  mapStyle: MapStyleId;
  pickMode?: boolean;
  preview?: { lat: number; lng: number; plan: PlanId } | null;
  onPick?: (lat: number, lng: number) => void;
  ref?: React.Ref<MapHandle>;
};

export default function MapCanvas({
  businesses,
  selectedId,
  onSelect,
  userPos,
  mapStyle,
  pickMode = false,
  preview = null,
  onPick,
  ref,
}: Props) {
  const holder = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const tileRef = useRef<L.TileLayer | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const userLayer = useRef<L.LayerGroup | null>(null);
  const previewLayer = useRef<L.LayerGroup | null>(null);
  const cbRef = useRef({ onSelect, onPick });
  cbRef.current = { onSelect, onPick };

  /* ------------------------------------------------------------ init map */
  useEffect(() => {
    if (mapRef.current || !holder.current) return;
    const map = L.map(holder.current, {
      zoomControl: false,
      attributionControl: true,
      preferCanvas: true,
      zoomSnap: 0.5,
      minZoom: 11,
      maxZoom: 19,
    }).setView([-13.1616, -74.2228], 15);

    map.createPane("pane-free");
    map.createPane("pane-gold");
    map.createPane("pane-platinum");
    map.getPane("pane-free")!.style.zIndex = "600";
    map.getPane("pane-gold")!.style.zIndex = "620";
    map.getPane("pane-platinum")!.style.zIndex = "640";
    map.getPane("pane-platinum")!.classList.add("platinum-pane");

    L.control.zoom({ position: "bottomleft" }).addTo(map);
    layerRef.current = L.layerGroup().addTo(map);
    userLayer.current = L.layerGroup().addTo(map);
    previewLayer.current = L.layerGroup().addTo(map);

    map.on("click", (e: L.LeafletMouseEvent) => {
      if (cbRef.current.onPick) cbRef.current.onPick(e.latlng.lat, e.latlng.lng);
    });

    mapRef.current = map;
    setTimeout(() => map.invalidateSize(), 250);

    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, []);

  /* ---------------------------------------------------------- tile layer */
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (tileRef.current) map.removeLayer(tileRef.current);
    tileRef.current = L.tileLayer(MAP_STYLES[mapStyle].url, {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &middot; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: "abcd",
      maxZoom: 19,
      detectRetina: true,
    }).addTo(map);
    tileRef.current.setZIndex(1);
  }, [mapStyle]);

  /* ----------------------------------------------------------- markers */
  const markersRef = useRef<Map<string, L.Marker>>(new Map());

  const signature = useMemo(
    () =>
      businesses
        .map(
          (b) =>
            `${b.id}:${b.plan}:${b.name}:${b.img}:${(b.boostedUntil ?? 0) > Date.now() ? 1 : 0}`
        )
        .join("|"),
    [businesses]
  );

  useEffect(() => {
    const map = mapRef.current;
    const group = layerRef.current;
    if (!map || !group) return;
    group.clearLayers();
    markersRef.current.clear();

    const ordered = [...businesses].sort(
      (a, b) => PLANS[b.plan].markerScale - PLANS[a.plan].markerScale
    );

    ordered.forEach((biz, i) => {
      const marker = L.marker([biz.lat, biz.lng], {
        icon: stickerIcon(biz, { index: i, active: biz.id === selectedId }),
        pane:
          biz.plan === "platinum"
            ? "pane-platinum"
            : biz.plan === "gold"
              ? "pane-gold"
              : "pane-free",
        riseOnHover: true,
        keyboard: false,
        title: biz.name,
      });
      marker.on("click", () => cbRef.current.onSelect(biz));
      marker.addTo(group);
      markersRef.current.set(biz.id, marker);
    });
  }, [signature]);

  /* highlight the selected sticker without re-mounting every marker */
  useEffect(() => {
    markersRef.current.forEach((marker, id) => {
      const el = marker.getElement();
      const inner = el?.querySelector<HTMLElement>(".sticker-marker");
      if (inner) inner.classList.toggle("is-active", id === selectedId);
    });
  }, [selectedId, signature]);

  /* ------------------------------------------------------- user position */
  useEffect(() => {
    const map = mapRef.current;
    const group = userLayer.current;
    if (!map || !group) return;
    group.clearLayers();
    if (!userPos) return;
    L.circle([userPos.lat, userPos.lng], {
      radius: Math.max(30, userPos.accuracy),
      color: "#38bdf8",
      weight: 2,
      fillColor: "#38bdf8",
      fillOpacity: 0.14,
      interactive: false,
    }).addTo(group);
    L.marker([userPos.lat, userPos.lng], {
      icon: L.divIcon({ className: "", html: '<div class="gps-dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] }),
      interactive: false,
      zIndexOffset: 1000,
    }).addTo(group);
  }, [userPos]);

  /* ---------------------------------------------------- editor preview pin */
  useEffect(() => {
    const map = mapRef.current;
    const group = previewLayer.current;
    if (!map || !group) return;
    group.clearLayers();
    if (!preview) return;
    const plan = PLANS[preview.plan];
    L.marker([preview.lat, preview.lng], {
      icon: L.divIcon({
        className: "sticker-wrap",
        html: `<div class="sticker-marker" style="--sticker-bg:${plan.markerBg};--sticker-scale:${plan.markerScale};--anim-speed:${plan.animSpeed};--float-delay:0s">
            <div class="sticker-content">
              <div class="sticker-text" data-label="Tu local">Tu local</div>
              <div class="sticker-bubble"><div class="sticker-img" style="display:grid;place-items:center;font-size:26px">📍</div></div>
            </div>
          </div>`,
        iconSize: [104, 108],
        iconAnchor: [52, 98],
      }),
      pane: "pane-platinum",
      zIndexOffset: 1200,
      interactive: false,
    }).addTo(group);
  }, [preview]);

  /* --------------------------------------------------------- imperative */
  useImperativeHandle(
    ref,
    () => ({
      flyTo: (lat, lng, zoom) =>
        mapRef.current?.flyTo([lat, lng], zoom ?? 16, { duration: 0.9 }),
      fit: (points) => {
        if (!mapRef.current || points.length === 0) return;
        if (points.length === 1) {
          mapRef.current.flyTo(points[0], 16, { duration: 0.8 });
          return;
        }
        mapRef.current.flyToBounds(L.latLngBounds(points).pad(0.25), { duration: 0.9 });
      },
      invalidate: () => mapRef.current?.invalidateSize(),
    }),
    []
  );

  return (
    <div
      ref={holder}
      className={pickMode ? "h-full w-full cursor-crosshair" : "h-full w-full"}
    />
  );
}
