import { useEffect, useMemo, useState } from "react";
import {
  COUPONS,
  PLANS,
  PLAN_ORDER,
  discountFor,
  priceLabel,
  yearlySavings,
} from "@/lib/plans";
import { useStore } from "@/lib/store";
import type { BillingInterval, PlanId } from "@/lib/types";
import {
  DAY,
  cardBrand,
  daysLeft,
  expiryValid,
  fmtDate,
  formatCardNumber,
  formatExpiry,
  luhnValid,
  money,
} from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Button, Divider, Field, inputCls, PlanChip } from "./ui";

type Step = "plan" | "card" | "secure" | "done";

const BRAND_LABEL: Record<string, string> = {
  visa: "VISA",
  mastercard: "Mastercard",
  amex: "Amex",
  card: "Tarjeta",
};

export default function CheckoutModal({
  open,
  onClose,
  initialPlan = "gold",
  onFinished,
}: {
  open: boolean;
  onClose: () => void;
  initialPlan?: PlanId;
  onFinished?: (plan: PlanId) => void;
}) {
  const {
    subscribe,
    changePlan,
    subscription,
    cards,
    toast,
    makeDefaultCard,
  } = useStore();
  const existing =
    !!subscription && subscription.plan !== "free" && subscription.status !== "canceled";

  const [step, setStep] = useState<Step>("plan");
  const [plan, setPlan] = useState<PlanId>(initialPlan);
  const [interval, setInterval] = useState<BillingInterval>("monthly");
  const [couponInput, setCouponInput] = useState("");
  const [coupon, setCoupon] = useState<string | null>(null);
  const [couponError, setCouponError] = useState("");
  const [useSaved, setUseSaved] = useState(true);
  const [card, setCard] = useState({ number: "", holder: "", exp: "", cvc: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [otp, setOtp] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [otpError, setOtpError] = useState("");
  const [loading, setLoading] = useState(false);
  const [agree, setAgree] = useState(true);
  const [receipt, setReceipt] = useState<{ number: string; amount: number; plan: PlanId } | null>(
    null
  );

  const defaultCard = cards.find((c) => c.isDefault) ?? cards[0];
  const totals = useMemo(() => discountFor(plan, interval, coupon), [plan, interval, coupon]);
  const tax = totals.total - totals.total / 1.18;

  useEffect(() => {
    if (!open) return;
    setStep("plan");
    setPlan(initialPlan);
    setUseSaved(Boolean(defaultCard));
    setCard({ number: "", holder: "", exp: "", cvc: "" });
    setErrors({});
    setOtp("");
    setOtpError("");
    setCoupon(null);
    setCouponInput("");
    setReceipt(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialPlan]);

  useEffect(() => {
    if (step === "secure") setOtpCode(String(Math.floor(100000 + Math.random() * 900000)));
  }, [step]);

  const applyCoupon = () => {
    const code = couponInput.trim().toUpperCase();
    if (!code) return;
    if (!COUPONS[code]) {
      setCouponError("Ese cupón no existe o expiró.");
      setCoupon(null);
      return;
    }
    setCouponError("");
    setCoupon(code);
    toast({ title: "Cupón aplicado", message: COUPONS[code].label, variant: "success" });
  };

  const validateCard = () => {
    if (useSaved && defaultCard) return {};
    const e: Record<string, string> = {};
    if (!luhnValid(card.number)) e.number = "Número de tarjeta inválido.";
    if (card.holder.trim().length < 4) e.holder = "Escribe el nombre del titular.";
    if (!expiryValid(card.exp)) e.exp = "Fecha inválida (MM/AA).";
    if (card.cvc.replace(/\D/g, "").length < 3) e.cvc = "CVC de 3 dígitos.";
    return e;
  };

  const finish = () => {
    const res = existing
      ? changePlan(plan, interval)
      : subscribe({
          plan,
          interval,
          coupon,
          cardId: useSaved && defaultCard ? defaultCard.id : null,
          card: useSaved && defaultCard ? undefined : card,
        });
    if (!res.ok) {
      toast({ title: "Pago rechazado", message: res.error, variant: "error" });
      setStep("card");
      return;
    }
    setReceipt({
      number: `SM-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      amount: totals.total,
      plan,
    });
    setStep("done");
    toast({
      title: existing ? "Plan actualizado" : "¡Suscripción activada!",
      message: `Plan ${PLANS[plan].name} · ${interval === "monthly" ? "mensual" : "anual"}`,
      variant: "success",
    });
    onFinished?.(plan);
  };

  return (
    <Shell open={open} onClose={onClose} step={step}>
      {/* -------------------------------------------------------- header */}
      <div className="flex items-center gap-3 border-b-2 border-ink/10 px-5 py-4">
        <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border-2 border-ink bg-gold text-xl shadow-[2px_2px_0_#14141b]">
          {step === "done" ? "🎉" : "💳"}
        </div>
        <div className="min-w-0 flex-1">
          <h2 className="font-display text-lg leading-tight font-extrabold">
            {step === "plan" && (existing ? "Cambiar de plan" : "Activa tu suscripción")}
            {step === "card" && "Datos de pago"}
            {step === "secure" && "Verificación 3-D Secure"}
            {step === "done" && "¡Listo! Estás dentro"}
          </h2>
          <p className="truncate text-[12px] font-semibold text-ink-soft/80">
            {step === "plan" && "Cancela cuando quieras · IGV incluido"}
            {step === "card" && "Conexión cifrada · no guardamos el CVC"}
            {step === "secure" && "Autorización de tu banco emisor"}
            {step === "done" && `Factura ${receipt?.number}`}
          </p>
        </div>
        {step !== "done" && step !== "plan" && (
          <button
            onClick={() => setStep(step === "secure" ? "card" : "plan")}
            className="rounded-full bg-ink/5 px-3 py-1 font-display text-[11px] font-bold press"
          >
            ← Atrás
          </button>
        )}
      </div>

      {/* ---------------------------------------------------- step: plans */}
      {step === "plan" && (
        <div className="no-bar max-h-[60vh] overflow-y-auto px-5 py-4">
          <div className="mb-4 flex items-center gap-1 rounded-full border-2 border-ink bg-cream p-1">
            {(["monthly", "yearly"] as BillingInterval[]).map((i) => (
              <button
                key={i}
                onClick={() => setInterval(i)}
                className={cn(
                  "flex-1 rounded-full px-3 py-1.5 font-display text-[12px] font-extrabold press",
                  interval === i ? "bg-ink text-white" : "text-ink-soft"
                )}
              >
                {i === "monthly" ? "Mensual" : `Anual · ${money(yearlySavings(plan))} off`}
              </button>
            ))}
          </div>

          <div className="space-y-2.5">
            {PLAN_ORDER.map((id) => {
              const p = PLANS[id];
              const active = plan === id;
              const current = subscription?.plan === id;
              return (
                <button
                  key={id}
                  onClick={() => setPlan(id)}
                  className={cn(
                    "w-full rounded-2xl border-[3px] p-3 text-left transition-all",
                    active
                      ? "border-ink bg-white shadow-[4px_4px_0_#14141b]"
                      : "border-ink/15 bg-cream hover:border-ink/40"
                  )}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span
                        className="grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 border-ink text-[11px] font-black"
                        style={{ background: p.markerBg }}
                      >
                        {active ? "✓" : ""}
                      </span>
                      <div>
                        <p className="font-display text-[15px] leading-none font-extrabold">
                          {p.name}
                          {current && (
                            <span className="ml-2 rounded-full bg-ink/10 px-2 py-0.5 align-middle text-[10px] font-bold uppercase">
                              actual
                            </span>
                          )}
                        </p>
                        <p className="mt-0.5 text-[11.5px] font-semibold text-ink-soft/80">
                          {p.tagline}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-display text-[15px] leading-none font-extrabold">
                        {priceLabel(id, interval)}
                      </p>
                      {id !== "free" && interval === "yearly" && (
                        <p className="text-[10px] font-bold text-mint">2 meses gratis</p>
                      )}
                    </div>
                  </div>
                  {active && (
                    <ul className="mt-2.5 grid gap-1 border-t-2 border-dashed border-ink/15 pt-2">
                      {p.features.map((f) => (
                        <li key={f} className="flex gap-1.5 text-[12px] font-semibold text-ink-soft">
                          <span className="text-mint">✔</span>
                          {f}
                        </li>
                      ))}
                    </ul>
                  )}
                </button>
              );
            })}
          </div>

          <Divider label="Cupón" />
          <div className="flex gap-2">
            <input
              value={couponInput}
              onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
              placeholder="MAPA20"
              className={inputCls}
            />
            <Button variant="dark" onClick={applyCoupon}>
              Aplicar
            </Button>
          </div>
          {couponError && <p className="mt-1 text-[11px] font-bold text-coral">{couponError}</p>}
          {coupon && (
            <p className="mt-1 text-[11px] font-bold text-emerald-600">
              ✔ {COUPONS[coupon].label} ({coupon})
            </p>
          )}
          <p className="mt-2 text-[11px] font-medium text-ink-soft/70">
            Prueba <b>MAPA20</b> (20% off), <b>BIENVENIDA</b> (primer mes gratis) o{" "}
            <b>AYACUCHO10</b>.
          </p>

          <div className="mt-4 space-y-1 rounded-2xl border-2 border-ink/15 bg-cream p-3 text-[12.5px] font-semibold">
            <Line
              label={`Plan ${PLANS[plan].name} · ${interval === "monthly" ? "mensual" : "anual"}`}
              value={money(totals.base)}
            />
            {totals.discount > 0 && (
              <Line
                label={`Descuento ${coupon} (-${totals.percent}%)`}
                value={`- ${money(totals.discount)}`}
                good
              />
            )}
            <Line label="IGV 18% (incluido)" value={money(+tax.toFixed(2))} muted />
            <div className="mt-1 flex items-center justify-between border-t-2 border-dashed border-ink/15 pt-1.5">
              <span className="font-display text-sm font-extrabold">Total hoy</span>
              <span className="font-display text-xl font-extrabold">{money(totals.total)}</span>
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------------ step: card */}
      {step === "card" && (
        <div className="no-bar max-h-[60vh] overflow-y-auto px-5 py-4">
          {cards.length > 0 && (
            <div className="mb-4 space-y-2">
              {cards.map((c) => (
                <button
                  key={c.id}
                  onClick={() => {
                    setUseSaved(true);
                    if (!c.isDefault) makeDefaultCard(c.id);
                  }}
                  className={cn(
                    "flex w-full items-center gap-3 rounded-2xl border-[3px] p-3 text-left",
                    useSaved && c.isDefault
                      ? "border-ink bg-white shadow-[3px_3px_0_#14141b]"
                      : "border-ink/15 bg-cream"
                  )}
                >
                  <span className="rounded-lg border-2 border-ink bg-ink px-2 py-1 font-display text-[11px] font-extrabold text-white">
                    {BRAND_LABEL[c.brand]}
                  </span>
                  <span className="flex-1 text-[13px] font-bold tracking-wider">
                    •••• •••• •••• {c.last4}
                  </span>
                  <span className="text-[11px] font-bold text-ink-soft">
                    {String(c.expMonth).padStart(2, "0")}/{String(c.expYear).slice(-2)}
                  </span>
                </button>
              ))}
              <button
                onClick={() => setUseSaved(false)}
                className={cn(
                  "w-full rounded-2xl border-[3px] p-3 text-center font-display text-[13px] font-extrabold",
                  !useSaved ? "border-ink bg-white shadow-[3px_3px_0_#14141b]" : "border-ink/15 bg-cream"
                )}
              >
                + Usar otra tarjeta
              </button>
            </div>
          )}

          {(!useSaved || cards.length === 0) && (
            <div className="space-y-3">
              <div className="relative overflow-hidden rounded-2xl border-[3px] border-ink bg-gradient-to-br from-plum via-plum-deep to-ink p-4 text-white shadow-[4px_4px_0_#14141b]">
                <div className="flex items-start justify-between">
                  <span className="font-display text-[11px] font-bold uppercase tracking-widest opacity-80">
                    {BRAND_LABEL[cardBrand(card.number)]}
                  </span>
                  <span className="text-lg">💳</span>
                </div>
                <p className="mt-5 font-mono text-lg tracking-[0.15em]">
                  {formatCardNumber(card.number) || "•••• •••• •••• ••••"}
                </p>
                <div className="mt-3 flex items-end justify-between text-[11px] font-bold uppercase">
                  <span className="max-w-[60%] truncate">{card.holder || "Nombre del titular"}</span>
                  <span>{card.exp || "MM/AA"}</span>
                </div>
              </div>

              <Field label="Número de tarjeta" error={errors.number} hint="Demo: 4242 4242 4242 4242">
                <input
                  value={formatCardNumber(card.number)}
                  onChange={(e) => setCard({ ...card, number: e.target.value })}
                  inputMode="numeric"
                  placeholder="4242 4242 4242 4242"
                  className={inputCls}
                />
              </Field>
              <Field label="Titular" error={errors.holder}>
                <input
                  value={card.holder}
                  onChange={(e) => setCard({ ...card, holder: e.target.value })}
                  placeholder="ANA QUISPE"
                  className={inputCls}
                />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Vence" error={errors.exp}>
                  <input
                    value={formatExpiry(card.exp)}
                    onChange={(e) => setCard({ ...card, exp: formatExpiry(e.target.value) })}
                    inputMode="numeric"
                    placeholder="12/29"
                    className={inputCls}
                  />
                </Field>
                <Field label="CVC" error={errors.cvc}>
                  <input
                    value={card.cvc}
                    onChange={(e) =>
                      setCard({ ...card, cvc: e.target.value.replace(/\D/g, "").slice(0, 4) })
                    }
                    inputMode="numeric"
                    placeholder="123"
                    className={inputCls}
                  />
                </Field>
              </div>
            </div>
          )}

          <label className="mt-4 flex cursor-pointer items-start gap-2 text-[11.5px] font-semibold text-ink-soft">
            <input
              type="checkbox"
              checked={agree}
              onChange={(e) => setAgree(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-plum"
            />
            Autorizo el cobro recurrente de {money(totals.total)} cada{" "}
            {interval === "monthly" ? "mes" : "año"} y acepto los términos. Puedo cancelar cuando
            quiera desde mi panel.
          </label>
        </div>
      )}

      {/* ---------------------------------------------------- step: secure */}
      {step === "secure" && (
        <div className="px-5 py-5">
          <div className="brutal rounded-2xl bg-cream p-4">
            <div className="flex items-center justify-between border-b-2 border-dashed border-ink/20 pb-3">
              <div>
                <p className="font-display text-[13px] font-extrabold">Banco emisor</p>
                <p className="text-[11px] font-semibold text-ink-soft">
                  {useSaved && defaultCard
                    ? `•••• ${defaultCard.last4}`
                    : `•••• ${card.number.replace(/\D/g, "").slice(-4)}`}
                </p>
              </div>
              <span className="rounded-full border-2 border-ink bg-white px-2 py-0.5 font-display text-[10px] font-extrabold">
                3-D SECURE
              </span>
            </div>
            <p className="mt-3 text-[12.5px] font-semibold text-ink-soft">
              Enviamos un código de 6 dígitos al celular registrado.{" "}
              <span className="text-ink">(simulación)</span>
            </p>
            <p className="my-2 rounded-xl border-2 border-dashed border-ink/30 bg-white py-2 text-center font-mono text-xl font-bold tracking-[0.35em]">
              {otpCode}
            </p>
            <input
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="· · · · · ·"
              inputMode="numeric"
              className={cn(inputCls, "text-center font-mono text-lg tracking-[0.3em]")}
            />
            {otpError && <p className="mt-1 text-[11px] font-bold text-coral">{otpError}</p>}
            <div className="mt-3 flex gap-2">
              <Button variant="white" size="sm" onClick={() => setOtp(otpCode)}>
                Autocompletar
              </Button>
              <Button
                variant="white"
                size="sm"
                onClick={() => {
                  setOtpCode(String(Math.floor(100000 + Math.random() * 900000)));
                  setOtp("");
                }}
              >
                Reenviar SMS
              </Button>
            </div>
          </div>
          <Button
            className="mt-4 w-full"
            size="lg"
            disabled={loading || otp.length !== 6}
            onClick={() => {
              if (otp !== otpCode) {
                setOtpError("Código incorrecto. Revisa el SMS simulado.");
                return;
              }
              setOtpError("");
              setLoading(true);
              window.setTimeout(() => {
                setLoading(false);
                finish();
              }, 1300);
            }}
          >
            {loading ? <span className="spin-slow inline-block">◌</span> : "🔒"} Pagar{" "}
            {money(totals.total)}
          </Button>
        </div>
      )}

      {/* ------------------------------------------------------ step: done */}
      {step === "done" && receipt && (
        <div className="px-5 py-6 text-center">
          <div className="mx-auto mb-3 grid h-16 w-16 place-items-center rounded-full border-[3px] border-ink bg-mint text-3xl shadow-[3px_3px_0_#14141b]">
            ✓
          </div>
          <h3 className="font-display text-xl font-extrabold">
            Plan {PLANS[receipt.plan].name} activo
          </h3>
          <p className="mt-1 text-[13px] font-semibold text-ink-soft">
            Cobro de {money(receipt.amount)} confirmado. Tus marcadores ya tienen el estilo{" "}
            {PLANS[receipt.plan].name.toLowerCase()}.
          </p>
          <div className="mx-auto mt-4 max-w-xs space-y-1 rounded-2xl border-2 border-dashed border-ink/25 bg-cream p-3 text-left text-[12px] font-semibold">
            <p className="flex justify-between">
              <span className="text-ink-soft/70">Factura</span>
              <b>{receipt.number}</b>
            </p>
            <p className="flex justify-between">
              <span className="text-ink-soft/70">Próximo cobro</span>
              <b>{fmtDate(Date.now() + (interval === "monthly" ? 30 * DAY : 365 * DAY))}</b>
            </p>
            <p className="flex justify-between">
              <span className="text-ink-soft/70">Impulsos</span>
              <b>{PLANS[receipt.plan].boosts}</b>
            </p>
          </div>
          <Button size="lg" className="mt-5 w-full" onClick={onClose}>
            Empezar a usar mi plan
          </Button>
        </div>
      )}

      {/* -------------------------------------------------------- footer */}
      {step === "plan" && (
        <div className="flex items-center gap-3 border-t-2 border-ink/10 px-5 py-4">
          <div className="flex-1 text-[11px] font-semibold text-ink-soft/70">
            <PlanChip plan={plan} /> {priceLabel(plan, interval)}
            {subscription?.status === "trialing" && (
              <> · {daysLeft(subscription.currentPeriodEnd)} días de prueba</>
            )}
          </div>
          <Button
            size="lg"
            variant="dark"
            onClick={() => {
              if (totals.total === 0) {
                const res = existing ? changePlan("free") : subscribe({ plan: "free", interval });
                if (res.ok) {
                  toast({ title: "Plan Básico activado", variant: "info" });
                  onClose();
                }
                return;
              }
              setErrors(validateCard());
              if (useSaved && defaultCard) setStep("secure");
              else setStep("card");
            }}
          >
            {totals.total === 0 ? "Activar gratis" : "Continuar"}
          </Button>
        </div>
      )}

      {step === "card" && (
        <div className="border-t-2 border-ink/10 px-5 py-4">
          <Button
            size="lg"
            className="w-full"
            onClick={() => {
              const e = validateCard();
              setErrors(e);
              if (Object.keys(e).length) return;
              if (!agree) {
                toast({
                  title: "Acepta los términos",
                  message: "Necesitamos tu autorización para el cobro.",
                  variant: "warning",
                });
                return;
              }
              if (totals.total === 0) finish();
              else setStep("secure");
            }}
          >
            {totals.total === 0 ? "Confirmar" : `Pagar ${money(totals.total)}`} →
          </Button>
        </div>
      )}
    </Shell>
  );
}

function Line({
  label,
  value,
  good,
  muted,
}: {
  label: string;
  value: string;
  good?: boolean;
  muted?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className={cn(muted ? "text-ink-soft/60" : "text-ink")}>{label}</span>
      <span className={cn("font-display font-extrabold", good && "text-emerald-600")}>{value}</span>
    </div>
  );
}

function Shell({
  open,
  onClose,
  step,
  children,
}: {
  open: boolean;
  onClose: () => void;
  step: Step;
  children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-[3200] flex items-start justify-center overflow-y-auto bg-ink/70 p-3 backdrop-blur-sm sm:items-center sm:p-6 hide-fade"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="pop-in relative my-auto w-full max-w-[440px] rounded-3xl border-[3px] border-ink bg-white shadow-[6px_8px_0_#14141b]">
        <button
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute -right-3 -top-3 z-20 grid h-10 w-10 place-items-center rounded-full border-2 border-ink bg-white text-lg font-black shadow-[2px_2px_0_#14141b] press"
        >
          ✕
        </button>
        {children}
        {step !== "done" && (
          <p className="rounded-b-3xl bg-ink/5 px-5 py-2 text-center text-[10.5px] font-bold uppercase tracking-wide text-ink-soft/60">
            Pago simulado · no se realiza ningún cargo real
          </p>
        )}
      </div>
    </div>
  );
}
