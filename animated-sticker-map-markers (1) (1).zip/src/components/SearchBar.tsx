import type { Category } from "@/lib/types";
import { cn } from "@/utils/cn";

export const CATEGORIES: (Category | "Todos")[] = [
  "Todos",
  "Café",
  "Restaurante",
  "Tienda",
  "Postres",
  "Servicios",
  "Salud",
  "Hoteles",
];

export const CAT_ICONS: Record<string, string> = {
  Todos: "✨",
  Café: "☕",
  Restaurante: "🍽️",
  Tienda: "🛍️",
  Postres: "🍦",
  Servicios: "🔧",
  Salud: "💊",
  Hoteles: "🛏️",
};

export type SortKey = "relevancia" | "rating" | "cercania" | "populares";

export const SORTS: { id: SortKey; label: string }[] = [
  { id: "relevancia", label: "Plan + relevancia" },
  { id: "rating", label: "Mejor valorados" },
  { id: "cercania", label: "Más cerca" },
  { id: "populares", label: "Más vistos" },
];

export default function SearchBar({
  query,
  onQuery,
  category,
  onCategory,
  sort,
  onSort,
  count,
  total,
  openOnly,
  onOpenOnly,
  onFit,
}: {
  query: string;
  onQuery: (v: string) => void;
  category: Category | "Todos";
  onCategory: (c: Category | "Todos") => void;
  sort: SortKey;
  onSort: (s: SortKey) => void;
  count: number;
  total: number;
  openOnly: boolean;
  onOpenOnly: (v: boolean) => void;
  onFit: () => void;
}) {
  return (
    <div className="pointer-events-auto flex w-full flex-col gap-2">
      <div className="brutal-sm flex items-center gap-2 rounded-full bg-white px-3 py-2">
        <span className="text-base leading-none">🔍</span>
        <input
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          placeholder="Buscar negocios, cafés, comida…"
          className="w-full bg-transparent text-sm font-semibold text-ink outline-none placeholder:text-ink-soft/50"
        />
        {query && (
          <button
            onClick={() => onQuery("")}
            className="grid h-6 w-6 place-items-center rounded-full bg-ink/10 text-xs font-black text-ink press"
            aria-label="Limpiar búsqueda"
          >
            ✕
          </button>
        )}
        <button
          onClick={onFit}
          title="Centrar en los resultados"
          className="hidden shrink-0 rounded-full bg-ink px-2.5 py-1 font-display text-[11px] font-bold text-white press sm:block"
        >
          {count}/{total}
        </button>
      </div>

      <div className="no-bar flex gap-1.5 overflow-x-auto pb-0.5">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => onCategory(c)}
            className={cn(
              "brutal-sm flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 font-display text-[12px] font-bold press",
              category === c ? "bg-ink text-white" : "bg-white text-ink hover:bg-cream"
            )}
          >
            <span>{CAT_ICONS[c]}</span>
            {c}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-1.5">
        <button
          onClick={() => onOpenOnly(!openOnly)}
          className={cn(
            "brutal-sm flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 font-display text-[12px] font-bold press",
            openOnly ? "bg-mint text-ink" : "bg-white text-ink"
          )}
        >
          {openOnly ? "🟢" : "🕐"} Abiertos
        </button>
        <div className="brutal-sm flex items-center gap-1 overflow-hidden rounded-full bg-white">
          {SORTS.map((s) => (
            <button
              key={s.id}
              onClick={() => onSort(s.id)}
              title={s.label}
              className={cn(
                "px-2.5 py-1.5 font-display text-[11px] font-bold whitespace-nowrap press",
                sort === s.id ? "bg-plum text-white" : "text-ink-soft hover:text-ink"
              )}
            >
              {s.label.split(" ")[0]}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
