import { useMemo, useState } from "react";
import { PLANS } from "@/lib/plans";
import { useMyBusinesses, useStore } from "@/lib/store";
import type { Business } from "@/lib/types";
import { isOpenNow, moneyShort, relative } from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Bars, Button, PlanChip, Progress, Sparkline, StatCard } from "./ui";

export default function MerchantPanel({
  open,
  onClose,
  onEdit,
  onView,
  onAdd,
  onUpgrade,
}: {
  open: boolean;
  onClose: () => void;
  onEdit: (b: Business) => void;
  onView: (b: Business) => void;
  onAdd: () => void;
  onUpgrade: () => void;
}) {
  const { subscription, boost, updateBusiness, toast, invoices } = useStore();
  const mine = useMyBusinesses();
  const [range, setRange] = useState<7 | 14 | 30>(14);
  const plan = PLANS[subscription?.plan ?? "free"];
  const isPro = subscription?.plan !== "free";

  const totals = useMemo(() => {
    const views = mine.reduce((a, b) => a + b.views, 0);
    const routes = mine.reduce((a, b) => a + b.routeClicks, 0);
    const trimmed = mine.map((b) => b.series.slice(-range));
    const series = trimmed[0]
      ? trimmed[0].map((_, i) => trimmed.reduce((a, s) => a + (s[i] ?? 0), 0))
      : [];
    return { views, routes, series, ctr: views ? (routes / views) * 100 : 0 };
  }, [mine, range]);

  const exportCsv = () => {
    if (!isPro) {
      toast({
        title: "Exportación exclusiva Gold/Platinum",
        message: "Sube de plan para descargar tus métricas en CSV.",
        variant: "warning",
      });
      return;
    }
    const rows = [
      ["negocio", "plan", "vistas", "rutas", "ctr_%", "rating", "resenas", "creado"],
      ...mine.map((b) => [
        b.name,
        b.plan,
        String(b.views),
        String(b.routeClicks),
        ((b.routeClicks / Math.max(1, b.views)) * 100).toFixed(1),
        b.rating.toFixed(1),
        String(b.ratingCount),
        new Date(b.createdAt).toISOString().slice(0, 10),
      ]),
    ];
    const csv = rows.map((r) => r.join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "stickermap-metricas.csv";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "CSV descargado", message: `${mine.length} negocios`, variant: "success" });
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[3050] flex items-start justify-center overflow-y-auto bg-ink/70 p-3 backdrop-blur-sm sm:items-center sm:p-6 hide-fade"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="pop-in relative my-auto w-full max-w-[720px] overflow-hidden rounded-3xl border-[3px] border-ink bg-white shadow-[6px_8px_0_#14141b]">
        <button
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute -right-3 -top-3 z-20 grid h-10 w-10 place-items-center rounded-full border-2 border-ink bg-white text-lg font-black shadow-[2px_2px_0_#14141b] press"
        >
          ✕
        </button>

        <div className="flex flex-wrap items-center gap-3 border-b-2 border-ink/10 bg-cream px-5 py-4">
          <span className="grid h-11 w-11 place-items-center rounded-2xl border-2 border-ink bg-white text-xl shadow-[2px_2px_0_#14141b]">
            📊
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="font-display text-lg leading-tight font-extrabold">Panel del comercio</h2>
            <p className="text-[12px] font-semibold text-ink-soft/80">
              Plan {plan.name} · {mine.length}/{plan.maxLocations} marcadores ·{" "}
              {invoices.filter((i) => i.status === "paid").length} pagos
            </p>
          </div>
          <Button size="sm" variant="dark" onClick={onAdd}>
            ➕ Nuevo local
          </Button>
        </div>

        <div className="no-bar max-h-[70vh] overflow-y-auto px-5 py-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatCard label="Impresiones" value={moneyShort(totals.views)} delta="+12%" icon="👁️" />
            <StatCard label="Rutas abiertas" value={moneyShort(totals.routes)} delta="+8%" icon="🧭" />
            <StatCard label="CTR" value={`${totals.ctr.toFixed(1)}%`} delta="+1.4%" icon="🎯" />
            <StatCard label="Impulsos" value={`${subscription?.addonBoosts ?? 0}`} icon="🔥" />
          </div>

          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <div className="brutal rounded-2xl bg-white p-3">
              <div className="mb-1 flex items-center justify-between">
                <p className="font-display text-[12px] font-bold uppercase tracking-wide text-ink-soft/70">
                  Tráfico · {range} días
                </p>
                <div className="flex gap-1">
                  {([7, 14, 30] as const).map((r) => (
                    <button
                      key={r}
                      onClick={() => setRange(r)}
                      className={cn(
                        "rounded-full border-2 border-ink px-2 py-0.5 text-[10px] font-extrabold press",
                        range === r ? "bg-ink text-white" : "bg-white text-ink"
                      )}
                    >
                      {r}d
                    </button>
                  ))}
                </div>
              </div>
              <Sparkline data={totals.series} height={70} />
            </div>
            <div className="brutal rounded-2xl bg-white p-3">
              <p className="mb-1 font-display text-[12px] font-bold uppercase tracking-wide text-ink-soft/70">
                Comparativa por local
              </p>
              <Bars data={mine.map((b) => b.series.slice(-range).reduce((a, x) => a + x, 0))} />
              <p className="mt-1 text-[11px] font-semibold text-ink-soft">
                {mine.map((b) => b.name).join(" · ") || "Sin locales aún"}
              </p>
            </div>
          </div>

          <div className="mt-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="font-display text-sm font-extrabold">Mis marcadores</p>
              <Button size="sm" variant="white" onClick={exportCsv}>
                ⬇ Exportar CSV
              </Button>
            </div>

            {mine.length === 0 && (
              <div className="rounded-2xl border-2 border-dashed border-ink/20 p-6 text-center">
                <p className="font-display text-base font-extrabold">Aún no publicas ningún local</p>
                <p className="mt-1 text-[13px] font-semibold text-ink-soft">
                  Registra tu negocio y aparecerá en el mapa en segundos.
                </p>
                <Button className="mt-3" variant="dark" onClick={onAdd}>
                  Registrar mi local
                </Button>
              </div>
            )}

            <div className="space-y-2">
              {mine.map((b) => {
                const boosted = (b.boostedUntil ?? 0) > Date.now();
                return (
                  <div key={b.id} className="brutal rounded-2xl bg-white p-3">
                    <div className="flex items-start gap-3">
                      <img
                        src={b.img}
                        alt={b.name}
                        className="h-14 w-14 shrink-0 rounded-xl border-2 border-ink object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-1.5">
                          <p className="truncate font-display text-[15px] font-extrabold leading-tight">
                            {b.name}
                          </p>
                          <PlanChip plan={b.plan} />
                          {boosted && (
                            <span className="rounded-full border-2 border-ink bg-coral px-2 py-0.5 text-[10px] font-extrabold text-white">
                              🔥 BOOST
                            </span>
                          )}
                          {!b.active && (
                            <span className="rounded-full border-2 border-ink bg-ink/10 px-2 py-0.5 text-[10px] font-extrabold">
                              PAUSADO
                            </span>
                          )}
                        </div>
                        <p className="mt-0.5 text-[11.5px] font-semibold text-ink-soft">
                          {b.category} · {isOpenNow(b.hours) ? "🟢 Abierto" : "⚪ Cerrado"} · creado{" "}
                          {relative(b.createdAt)}
                        </p>
                        <div className="mt-1.5 grid grid-cols-3 gap-2 text-[11px] font-bold">
                          <span className="rounded-lg bg-ink/5 px-2 py-1">👁️ {moneyShort(b.views)}</span>
                          <span className="rounded-lg bg-ink/5 px-2 py-1">
                            🧭 {moneyShort(b.routeClicks)}
                          </span>
                          <span className="rounded-lg bg-ink/5 px-2 py-1">
                            ⭐ {b.rating.toFixed(1)} ({b.ratingCount})
                          </span>
                        </div>
                        <Progress
                          className="mt-2"
                          value={Math.min(100, (b.views / Math.max(1, plan.maxLocations * 1200)) * 100)}
                        />
                      </div>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      <Button size="sm" variant="white" onClick={() => onEdit(b)}>
                        ✏️ Editar
                      </Button>
                      <Button size="sm" variant="primary" onClick={() => onView(b)}>
                        🗺️ Ver en el mapa
                      </Button>
                      <Button
                        size="sm"
                        variant="gold"
                        disabled={boosted || (subscription?.addonBoosts ?? 0) <= 0}
                        onClick={() => {
                          boost(b.id);
                          toast({
                            title: "¡Local impulsado!",
                            message: `${b.name} destaca durante 30 minutos`,
                            variant: "success",
                          });
                        }}
                      >
                        🔥 Impulsar
                      </Button>
                      <Button
                        size="sm"
                        variant="white"
                        onClick={() => {
                          updateBusiness(b.id, { active: !b.active });
                          toast({
                            title: b.active ? "Marcador pausado" : "Marcador visible",
                            variant: "info",
                          });
                        }}
                      >
                        {b.active ? "⏸ Pausar" : "▶ Activar"}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {!isPro && (
            <div className="brutal mt-4 rounded-2xl bg-gold/30 p-3">
              <p className="font-display text-[13px] font-extrabold">
                Desbloquea métricas completas y exportación
              </p>
              <p className="text-[12px] font-semibold text-ink-soft">
                Gold añade histórico de 30 días, comparativas y CSV. Platinum añade cupones y
                prioridad máxima.
              </p>
              <Button size="sm" variant="dark" className="mt-2" onClick={onUpgrade}>
                Ver planes
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
