import { useMemo, useState } from "react";
import { PLANS, priceLabel, yearlySavings } from "@/lib/plans";
import { useMyBusinesses, useStore } from "@/lib/store";
import type { Invoice, PaymentCard } from "@/lib/types";
import {
  cardBrand,
  daysLeft,
  expiryValid,
  fmtDate,
  formatCardNumber,
  formatExpiry,
  luhnValid,
  money,
} from "@/lib/utils";
import { cn } from "@/utils/cn";
import { Button, Field, inputCls, PlanChip, Progress } from "./ui";

const BRAND_LABEL: Record<string, string> = {
  visa: "VISA",
  mastercard: "Mastercard",
  amex: "Amex",
  card: "Tarjeta",
};

const STATUS_TONE: Record<string, string> = {
  paid: "bg-mint text-ink",
  open: "bg-gold text-ink",
  refunded: "bg-sky text-ink",
  failed: "bg-coral text-white",
};

export default function BillingModal({
  open,
  onClose,
  onChangePlan,
}: {
  open: boolean;
  onClose: () => void;
  onChangePlan: (plan?: "gold" | "platinum") => void;
}) {
  const {
    subscription,
    cards,
    invoices,
    cancelSubscription,
    resumeSubscription,
    reactivateSubscription,
    removeCard,
    makeDefaultCard,
    addCard,
    payInvoice,
    user,
    updateProfile,
    resetDemo,
    toast,
  } = useStore();
  const mine = useMyBusinesses();
  const [tab, setTab] = useState<"sub" | "pay" | "inv" | "me">("sub");
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [newCard, setNewCard] = useState({ number: "", holder: "", exp: "", cvc: "" });
  const [cardErr, setCardErr] = useState("");
  const [profile, setProfile] = useState({
    name: user?.name ?? "",
    email: user?.email ?? "",
    businessName: user?.businessName ?? "",
  });

  const plan = PLANS[subscription?.plan ?? "free"];
  const totalSpend = useMemo(
    () => invoices.filter((i) => i.status === "paid").reduce((a, i) => a + i.amount, 0),
    [invoices]
  );

  const downloadInvoice = (inv: Invoice) => {
    const lines = [
      "STICKERMAP SAC · Recibo de pago",
      "--------------------------------",
      `Recibo:  ${inv.number}`,
      `Fecha:    ${fmtDate(inv.date)}`,
      `Concepto: ${inv.description}`,
      `Estado:   ${inv.status.toUpperCase()}`,
      `Total:    ${money(inv.amount)} ${inv.currency}`,
      "",
      `Cliente:  ${user?.businessName ?? user?.name ?? ""} <${user?.email ?? ""}>`,
      "RUC 20481234567 · Ayacucho, Perú",
      "Gracias por anunciar en StickerMap 💜",
    ].join("\n");
    const url = URL.createObjectURL(new Blob([lines], { type: "text/plain" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `${inv.number}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Recibo descargado", message: inv.number, variant: "success" });
  };

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[3100] flex items-start justify-center overflow-y-auto bg-ink/70 p-3 backdrop-blur-sm sm:items-center sm:p-6 hide-fade"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="pop-in relative my-auto w-full max-w-[560px] overflow-hidden rounded-3xl border-[3px] border-ink bg-white shadow-[6px_8px_0_#14141b]">
        <button
          onClick={onClose}
          aria-label="Cerrar"
          className="absolute -right-3 -top-3 z-20 grid h-10 w-10 place-items-center rounded-full border-2 border-ink bg-white text-lg font-black shadow-[2px_2px_0_#14141b] press"
        >
          ✕
        </button>

        <div className="flex items-center gap-3 border-b-2 border-ink/10 bg-cream px-5 py-4">
          <div
            className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border-2 border-ink font-display text-lg font-extrabold shadow-[2px_2px_0_#14141b]"
            style={{ background: plan.markerBg }}
          >
            {user?.name?.[0] ?? "?"}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-base font-extrabold leading-tight">
              {user?.businessName ?? "Mi negocio"}
            </p>
            <p className="truncate text-[12px] font-semibold text-ink-soft/80">
              {user?.email} · Plan {plan.name}
            </p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-bold uppercase text-ink-soft/60">Total pagado</p>
            <p className="font-display text-lg font-extrabold leading-none">{money(totalSpend)}</p>
          </div>
        </div>

        <div className="no-bar flex gap-1 overflow-x-auto border-b-2 border-ink/10 px-4 pt-3">
          {(
            [
              ["sub", "Suscripción"],
              ["pay", "Pagos"],
              ["inv", `Facturas (${invoices.length})`],
              ["me", "Cuenta"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={cn(
                "relative shrink-0 px-3 pb-2 font-display text-[13px] font-bold transition-colors",
                tab === id ? "text-ink" : "text-ink-soft/60 hover:text-ink"
              )}
            >
              {label}
              {tab === id && (
                <span className="absolute inset-x-2 -bottom-[2px] h-1 rounded-full bg-plum" />
              )}
            </button>
          ))}
        </div>

        <div className="no-bar max-h-[58vh] overflow-y-auto px-5 py-4">
          {tab === "sub" && subscription && (
            <div className="space-y-4">
              <div className="brutal rounded-2xl bg-cream p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <PlanChip plan={subscription.plan} />
                      <span
                        className={cn(
                          "rounded-full border-2 border-ink px-2 py-0.5 text-[10px] font-extrabold uppercase",
                          subscription.status === "active"
                            ? "bg-mint text-ink"
                            : subscription.status === "trialing"
                              ? "bg-sky text-ink"
                              : "bg-coral text-white"
                        )}
                      >
                        {subscription.status === "trialing"
                          ? "En prueba"
                          : subscription.status === "past_due"
                            ? "Pago pendiente"
                            : subscription.status === "active"
                              ? "Activa"
                              : "Cancelada"}
                      </span>
                    </div>
                    <p className="mt-1.5 text-[12.5px] font-semibold text-ink-soft">
                      {subscription.interval === "monthly" ? "Mensual" : "Anual"} ·{" "}
                      {priceLabel(subscription.plan, subscription.interval)}
                      {subscription.coupon && (
                        <>
                          {" · cupón "}
                          <b>{subscription.coupon.code}</b> (-{subscription.coupon.percentOff}%)
                        </>
                      )}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase text-ink-soft/60">Renovación</p>
                    <p className="font-display text-sm font-extrabold">
                      {fmtDate(subscription.currentPeriodEnd)}
                    </p>
                  </div>
                </div>

                <div className="mt-3">
                  <Progress
                    value={
                      100 -
                      ((subscription.currentPeriodEnd - Date.now()) /
                        (subscription.currentPeriodEnd - subscription.currentPeriodStart || 1)) *
                        100
                    }
                  />
                  <p className="mt-1 text-[11px] font-bold text-ink-soft">
                    {subscription.cancelAtPeriodEnd
                      ? `Se cancela en ${daysLeft(subscription.currentPeriodEnd)} días`
                      : `${daysLeft(subscription.currentPeriodEnd)} días restantes del ciclo`}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <MiniStat label="Marcadores" value={`${mine.length}/${plan.maxLocations}`} />
                <MiniStat label="Impulsos" value={`${subscription.addonBoosts}`} />
                <MiniStat label="Sello" value={plan.verified ? "Verificado" : "Básico"} />
              </div>

              <div className="space-y-1.5">
                {plan.limits.map((l) => (
                  <div
                    key={l.label}
                    className="flex items-center justify-between rounded-xl bg-ink/5 px-3 py-1.5 text-[12px] font-semibold"
                  >
                    <span className="text-ink-soft">{l.label}</span>
                    <b>{l.value}</b>
                  </div>
                ))}
              </div>

              {subscription.status === "past_due" && (
                <div className="brutal rounded-2xl bg-coral/15 p-3">
                  <p className="font-display text-[13px] font-extrabold">Pago pendiente</p>
                  <p className="text-[12px] font-semibold text-ink-soft">
                    Tus marcadores vuelven al estilo Básico hasta que se complete el cobro.
                  </p>
                  <Button
                    size="sm"
                    variant="dark"
                    className="mt-2"
                    onClick={() => {
                      reactivateSubscription();
                      toast({
                        title: "Cobro reintentado",
                        message: "Suscripción activa de nuevo 💜",
                        variant: "success",
                      });
                    }}
                  >
                    Reintentar pago
                  </Button>
                </div>
              )}

              {subscription.plan !== "platinum" && (
                <div className="brutal rounded-2xl bg-gold/30 p-3">
                  <p className="font-display text-[13px] font-extrabold">
                    ⭐ Sube a {PLANS[subscription.plan === "free" ? "gold" : "platinum"].name}
                  </p>
                  <p className="text-[12px] font-semibold text-ink-soft">
                    {subscription.plan === "free"
                      ? "Marcador dorado más grande, 5 locales y estadísticas de 30 días."
                      : `Corona VIP, 25 locales, cupones y ${money(yearlySavings("platinum"))} de ahorro al pagar anual.`}
                  </p>
                  <Button
                    size="sm"
                    variant="dark"
                    className="mt-2"
                    onClick={() =>
                      onChangePlan(subscription.plan === "free" ? "gold" : "platinum")
                    }
                  >
                    Ver plan {subscription.plan === "free" ? "Gold" : "Platinum"}
                  </Button>
                </div>
              )}

              {subscription.interval === "monthly" && subscription.plan !== "free" && (
                <div className="flex items-center justify-between gap-3 rounded-2xl border-2 border-dashed border-ink/25 p-3">
                  <div>
                    <p className="font-display text-[13px] font-extrabold">Pasa a anual y ahorra</p>
                    <p className="text-[11.5px] font-semibold text-ink-soft">
                      {money(yearlySavings(subscription.plan))} · 2 meses gratis
                    </p>
                  </div>
                  <Button size="sm" variant="primary" onClick={() => onChangePlan(undefined)}>
                    Cambiar
                  </Button>
                </div>
              )}

              {subscription.cancelAtPeriodEnd ? (
                <div className="brutal rounded-2xl bg-coral/15 p-3">
                  <p className="font-display text-[13px] font-extrabold">
                    Suscripción programada para cancelarse
                  </p>
                  <p className="text-[12px] font-semibold text-ink-soft">
                    Mantienes los beneficios hasta el {fmtDate(subscription.currentPeriodEnd)}.
                  </p>
                  <Button
                    size="sm"
                    variant="dark"
                    className="mt-2"
                    onClick={() => {
                      resumeSubscription();
                      toast({ title: "Suscripción reactivada", variant: "success" });
                    }}
                  >
                    Reactivar ahora
                  </Button>
                </div>
              ) : (
                confirmCancel && (
                  <div className="brutal rounded-2xl bg-cream p-3">
                    <p className="font-display text-[13px] font-extrabold">
                      ¿Seguro que quieres cancelar?
                    </p>
                    <p className="text-[12px] font-semibold text-ink-soft">
                      Perderás el marcador destacado, el sello verificado y los impulsos. Siempre
                      puedes volver al plan Básico gratis.
                    </p>
                    <div className="mt-2 flex gap-2">
                      <Button
                        size="sm"
                        variant="danger"
                        onClick={() => {
                          cancelSubscription();
                          setConfirmCancel(false);
                          toast({
                            title: "Cancelación programada",
                            message: "Te esperamos cuando quieras volver 💜",
                            variant: "info",
                          });
                        }}
                      >
                        Cancelar plan
                      </Button>
                      <Button size="sm" variant="white" onClick={() => setConfirmCancel(false)}>
                        Mantener plan
                      </Button>
                    </div>
                  </div>
                )
              )}

              <div className="flex flex-wrap gap-2">
                {!subscription.cancelAtPeriodEnd &&
                  subscription.plan !== "free" &&
                  !confirmCancel && (
                    <Button size="sm" variant="white" onClick={() => setConfirmCancel(true)}>
                      Cancelar suscripción
                    </Button>
                  )}
                <Button size="sm" variant="primary" onClick={() => onChangePlan(undefined)}>
                  Cambiar de plan
                </Button>
                {subscription.status === "canceled" && (
                  <Button size="sm" variant="dark" onClick={reactivateSubscription}>
                    Reactivar
                  </Button>
                )}
              </div>
            </div>
          )}

          {tab === "pay" && (
            <div className="space-y-3">
              {cards.length === 0 && (
                <p className="rounded-2xl border-2 border-dashed border-ink/20 p-4 text-center text-[13px] font-semibold text-ink-soft/80">
                  Todavía no tienes tarjetas guardadas.
                </p>
              )}
              {cards.map((c: PaymentCard) => (
                <div
                  key={c.id}
                  className={cn(
                    "flex items-center gap-3 rounded-2xl border-[3px] p-3",
                    c.isDefault
                      ? "border-ink bg-white shadow-[3px_3px_0_#14141b]"
                      : "border-ink/15 bg-cream"
                  )}
                >
                  <span className="rounded-lg border-2 border-ink bg-ink px-2 py-1 font-display text-[11px] font-extrabold text-white">
                    {BRAND_LABEL[c.brand]}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] font-bold tracking-wider">•••• •••• •••• {c.last4}</p>
                    <p className="text-[11px] font-semibold text-ink-soft">
                      {c.holder} · {String(c.expMonth).padStart(2, "0")}/
                      {String(c.expYear).slice(-2)}
                      {c.isDefault && <b className="ml-2 text-plum">· predeterminada</b>}
                    </p>
                  </div>
                  {!c.isDefault && (
                    <Button size="sm" variant="white" onClick={() => makeDefaultCard(c.id)}>
                      Usar
                    </Button>
                  )}
                  <Button size="sm" variant="danger" onClick={() => removeCard(c.id)}>
                    🗑
                  </Button>
                </div>
              ))}

              <div className="brutal rounded-2xl bg-cream p-3">
                <p className="mb-2 font-display text-[13px] font-extrabold">Añadir tarjeta</p>
                <div className="space-y-2">
                  <input
                    value={formatCardNumber(newCard.number)}
                    onChange={(e) => setNewCard({ ...newCard, number: e.target.value })}
                    inputMode="numeric"
                    placeholder="4242 4242 4242 4242"
                    className={inputCls}
                  />
                  <input
                    value={newCard.holder}
                    onChange={(e) => setNewCard({ ...newCard, holder: e.target.value })}
                    placeholder="Titular de la tarjeta"
                    className={inputCls}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      value={formatExpiry(newCard.exp)}
                      onChange={(e) => setNewCard({ ...newCard, exp: formatExpiry(e.target.value) })}
                      inputMode="numeric"
                      placeholder="MM/AA"
                      className={inputCls}
                    />
                    <input
                      value={newCard.cvc}
                      onChange={(e) =>
                        setNewCard({ ...newCard, cvc: e.target.value.replace(/\D/g, "").slice(0, 4) })
                      }
                      inputMode="numeric"
                      placeholder="CVC"
                      className={inputCls}
                    />
                  </div>
                  {cardErr && <p className="text-[11px] font-bold text-coral">{cardErr}</p>}
                  <Button
                    size="sm"
                    variant="dark"
                    className="w-full"
                    onClick={() => {
                      if (!luhnValid(newCard.number)) return setCardErr("Número de tarjeta inválido.");
                      if (!expiryValid(newCard.exp)) return setCardErr("Fecha de expiración inválida.");
                      if (newCard.cvc.replace(/\D/g, "").length < 3) return setCardErr("CVC inválido.");
                      setCardErr("");
                      const created = addCard(newCard);
                      if (created) {
                        setNewCard({ number: "", holder: "", exp: "", cvc: "" });
                        toast({
                          title: "Tarjeta guardada",
                          message: `•••• ${created.last4} lista para cobros`,
                          variant: "success",
                        });
                      }
                    }}
                  >
                    Guardar tarjeta {BRAND_LABEL[cardBrand(newCard.number)]}
                  </Button>
                </div>
              </div>
            </div>
          )}

          {tab === "inv" && (
            <div className="space-y-2">
              {invoices.length === 0 && (
                <p className="rounded-2xl border-2 border-dashed border-ink/20 p-6 text-center text-[13px] font-semibold text-ink-soft/80">
                  Aún no tienes facturas. Activa un plan de pago para verlas aquí.
                </p>
              )}
              {invoices.map((inv) => (
                <div
                  key={inv.id}
                  className="flex items-center gap-2 rounded-2xl border-2 border-ink/15 bg-cream p-3"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold">{inv.description}</p>
                    <p className="text-[11px] font-semibold text-ink-soft">
                      {inv.number} · {fmtDate(inv.date)}
                      {inv.periodEnd ? ` · hasta ${fmtDate(inv.periodEnd)}` : ""}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "rounded-full border-2 border-ink px-2 py-0.5 text-[10px] font-extrabold uppercase",
                      STATUS_TONE[inv.status]
                    )}
                  >
                    {inv.status}
                  </span>
                  <span className="font-display text-sm font-extrabold">{money(inv.amount)}</span>
                  {inv.status === "failed" || inv.status === "open" ? (
                    <Button
                      size="sm"
                      variant="dark"
                      onClick={() => {
                        payInvoice(inv.id);
                        toast({ title: "Pago completado", message: inv.number, variant: "success" });
                      }}
                    >
                      Pagar
                    </Button>
                  ) : (
                    <Button size="sm" variant="white" onClick={() => downloadInvoice(inv)}>
                      ⬇
                    </Button>
                  )}
                </div>
              ))}
              <p className="pt-1 text-center text-[11px] font-semibold text-ink-soft/60">
                Recibos con RUC 20481234567 · soporte@stickermap.pe
              </p>
            </div>
          )}

          {tab === "me" && (
            <div className="space-y-3">
              <Field label="Responsable">
                <input
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className={inputCls}
                />
              </Field>
              <Field label="Negocio">
                <input
                  value={profile.businessName}
                  onChange={(e) => setProfile({ ...profile, businessName: e.target.value })}
                  className={inputCls}
                />
              </Field>
              <Field label="Correo de facturación">
                <input
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className={inputCls}
                />
              </Field>
              <Button
                variant="dark"
                onClick={() => {
                  updateProfile(profile);
                  toast({ title: "Datos actualizados", variant: "success" });
                }}
              >
                Guardar cambios
              </Button>
              <div className="rounded-2xl border-2 border-dashed border-ink/20 p-3">
                <p className="font-display text-[13px] font-extrabold">Zona de pruebas</p>
                <p className="text-[12px] font-semibold text-ink-soft">
                  Reinicia la demo con los datos de ejemplo (negocios, suscripción y facturas).
                </p>
                <Button
                  size="sm"
                  variant="danger"
                  className="mt-2"
                  onClick={() => {
                    resetDemo();
                    onClose();
                    toast({ title: "Demo reiniciada", variant: "info" });
                  }}
                >
                  Reiniciar demo
                </Button>
              </div>
            </div>
          )}
        </div>

        <p className="rounded-b-3xl bg-ink/5 px-5 py-2 text-center text-[10.5px] font-bold uppercase tracking-wide text-ink-soft/60">
          Plan {plan.name} · {priceLabel(plan.id, subscription?.interval ?? "monthly")}
        </p>
      </div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border-2 border-ink/15 bg-white p-2 text-center">
      <p className="text-[10px] font-bold uppercase tracking-wide text-ink-soft/60">{label}</p>
      <p className="font-display text-base font-extrabold leading-tight">{value}</p>
    </div>
  );
}
