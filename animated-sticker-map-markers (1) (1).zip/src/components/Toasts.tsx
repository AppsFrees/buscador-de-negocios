import { useEffect, useRef } from "react";
import { useStore } from "@/lib/store";
import { cn } from "@/utils/cn";

const ICONS: Record<string, string> = {
  success: "✅",
  error: "⚠️",
  info: "💡",
  warning: "🔔",
};

const TONES: Record<string, string> = {
  success: "bg-mint text-ink",
  error: "bg-coral text-white",
  info: "bg-white text-ink",
  warning: "bg-gold text-ink",
};

export default function Toasts() {
  const { toasts, dismissToast } = useStore();
  const timers = useRef<Record<string, number>>({});

  useEffect(() => {
    toasts.forEach((t) => {
      if (timers.current[t.id]) return;
      timers.current[t.id] = window.setTimeout(() => dismissToast(t.id), 4200);
    });
  }, [toasts, dismissToast]);

  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-[5000] flex flex-col items-center gap-2 px-3">
      {toasts.map((t) => (
        <button
          key={t.id}
          onClick={() => dismissToast(t.id)}
          className={cn(
            "pop-in pointer-events-auto flex max-w-[92vw] items-start gap-2 rounded-2xl border-[2.5px] border-ink px-4 py-2.5 text-left shadow-[3px_4px_0_#14141b] sm:max-w-md",
            TONES[t.variant]
          )}
        >
          <span className="text-lg leading-none">{ICONS[t.variant]}</span>
          <span className="block">
            <span className="block font-display text-sm font-extrabold">{t.title}</span>
            {t.message && (
              <span className="block text-[12px] font-medium leading-snug opacity-90">
                {t.message}
              </span>
            )}
          </span>
        </button>
      ))}
    </div>
  );
}
